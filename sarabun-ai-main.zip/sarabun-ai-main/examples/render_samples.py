"""python -m examples.render_samples out/"""
import sys
from pathlib import Path

from examples.samples import ALL
from sarabun.render import DocxRenderer

out = Path(sys.argv[1] if len(sys.argv) > 1 else "out")
out.mkdir(parents=True, exist_ok=True)
r = DocxRenderer()
for name, doc in ALL.items():
    print(r.render_to(doc, out / f"{name}.docx"))

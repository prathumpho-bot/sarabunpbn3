![cover](docs/%E0%B9%82%E0%B8%9E%E0%B8%AA%E0%B8%95%E0%B9%8C1_%E0%B8%9B%E0%B8%81_1200x630.png)
# SARABUN.AI

ผู้ช่วยร่างหนังสือราชการไทยด้วย AI — ร่างถ้อยคำด้วย LLM แล้วจัดรูปแบบ .docx ตามระเบียบสำนักนายกรัฐมนตรีว่าด้วยงานสารบรรณ
และแนวทางการพิมพ์หนังสือราชการ (นร 0106/ว 2019) พร้อมโปรไฟล์ของการประปาส่วนภูมิภาค (กปภ.)

*Thai government document drafting assistant: an LLM writes the wording as structured JSON, a deterministic template engine
lays out the .docx according to the Thai Prime Minister's Office Regulation on Correspondence (สารบรรณ) and the official
typing guideline. Works with on-premise LLMs (vLLM/Ollama) or the [ThaiLLM](https://thaillm.or.th) API.*

```
คำขอภาษาไทย ─► แนะนำชนิดหนังสือ ─► ร่าง (JSON ตาม schema) ─► เติมข้อมูลหน่วยงาน/คำขึ้นต้น-ลงท้าย ─► ตรวจตามระเบียบ ─► .docx
```

**หลักการ:** LLM เขียนถ้อยคำเท่านั้น — รูปแบบ (ขอบ ฟอนต์ ตรา ระยะ ย่อหน้า เลขไทย) ควบคุมด้วยโค้ดและทดสอบเทียบแม่แบบทางการ

## ความสามารถ

- หนังสือ 11 ชนิดตามระเบียบงานสารบรรณ: ภายนอก ภายใน (บันทึกข้อความ แบบ 2/1 และ 2/2) ประทับตรา คำสั่ง ระเบียบ ข้อบังคับ
  ประกาศ/แจ้งความ แถลงการณ์ ข่าว หนังสือรับรอง รายงานการประชุม
- ตรวจตามระเบียบ (อ้างเลขข้อ): ที่/เลขที่ วันที่ โครง 3 ภาค คู่คำขึ้นต้น-ลงท้าย ภาษาพูด ช่อง [ระบุ] ที่ยังไม่กรอก ฯลฯ + ตรวจไฟล์ .docx
- โปรไฟล์หน่วยงาน: `opm` (แนวทางกลาง) และ `pwa` (คู่มือและแม่แบบ กปภ.) — เพิ่มหน่วยงานใหม่ได้โดยไม่แก้แกนหลัก
- LLM: เซิร์ฟเวอร์ภายใน (OpenAI-compatible) หรือ ThaiLLM API พร้อมปิดบังข้อมูลส่วนบุคคล จำกัดอัตรา และ fallback
- หนังสือชั้นความลับไม่ถูกส่งให้ LLM ภายนอก
- ใช้ได้ทั้งบรรทัดคำสั่ง (`python -m sarabun`), REST API + หน้าเว็บ และเป็นไลบรารี Python

## เริ่มใช้งาน (เฉพาะส่วนสร้างเอกสาร)

ต้องมี Python 3.10+

```bash
pip install -r requirements-core.txt        # python-docx, pydantic, httpx, pillow
cp .env.example .env                        # Windows: copy — แล้วใส่ THAILLM_API_KEY
python -m sarabun "ขออนุมัติจัดอบรมการใช้ระบบให้พนักงาน ๕๐ คน วันที่ ๑๐ พ.ย. ๒๕๖๙" -t memo -o บันทึก.docx
```

| ตัวเลือก | ความหมาย |
| --- | --- |
| `-t memo` | ชนิดหนังสือ (ไม่ใส่ = ให้ LLM แนะนำ): memo, external_letter, stamp_letter, order, regulation, bylaw, announcement, statement, news, certificate, minutes |
| `--provider` | `thaillm` (ค่าเริ่มต้นของ CLI) / `onprem` / `thaillm+onprem` |
| `--model` | ThaiLLM: `typhoon` (ค่าเริ่มต้น) / `openthaigpt` / `pathumma` / `thalle` |
| `--profile` | `pwa` (ค่าเริ่มต้น) / `opm` |
| `--profile-file profile.json` | ข้อมูลหน่วยงาน/ผู้ลงนาม (ดู `profile.example.json`) หรือ `--dept --phone --signer --position` |
| `--json-out ร่าง.json` | เก็บร่างไว้แก้ต่อ |
| `--from-json ร่าง.json --revise "..."` | สั่งแก้ร่างเดิม |
| `--from-json ร่าง.json` | จัดรูปแบบจากร่างที่แก้เอง (ไม่เรียก LLM) |
| `--secrecy ลับ` | ชั้นความลับ (ไม่ส่งให้ LLM ภายนอก) |

เครื่องที่เปิดไฟล์ควรมีฟอนต์ TH SarabunIT๙ (โปรไฟล์ pwa) หรือ TH SarabunPSK (โปรไฟล์ opm)

## ใช้เป็นไลบรารี

```python
from sarabun.llm import llm_from_env
from sarabun.render import DocxRenderer
from sarabun.schema import DocType
from sarabun.service import DraftService, UserProfile
from sarabun.style import get_spec

svc = DraftService(llm_from_env("thaillm"), DocxRenderer(get_spec("pwa")))
doc = svc.draft("ขออนุมัติจัดอบรม ...", DocType.MEMO, UserProfile(department="กอง ..."))
print(svc.check(doc))               # ผลตรวจตามระเบียบ
open("บันทึก.docx", "wb").write(svc.render(doc))
```

## LLM

| `SARABUN_LLM_PROVIDER` | ใช้อะไร | ข้อมูลออกนอกหน่วยงาน |
| --- | --- | --- |
| `onprem` (ค่าเริ่มต้นของ API) | เซิร์ฟเวอร์ภายใน OpenAI-compatible (`SARABUN_LLM_URL`, `SARABUN_LLM_MODEL`) | ไม่ |
| `thaillm` | [ThaiLLM API](https://thaillm.or.th) (`THAILLM_API_KEY`, `THAILLM_MODEL`) | ใช่ — ปิดบังเลขบัตร โทรศัพท์ อีเมล เลขบัญชีก่อนส่ง |
| `thaillm+onprem` | ThaiLLM ก่อน ล้ม/เกินโควตาใช้เซิร์ฟเวอร์ภายใน; หนังสือลับใช้เซิร์ฟเวอร์ภายในเสมอ | บางส่วน |

ThaiLLM: endpoint `https://thaillm.or.th/api/v1/chat/completions`, auth `Authorization: Bearer` หรือ `apikey`,
rate limit 5 ครั้ง/วินาที 200 ครั้ง/นาที (ระบบจำกัดฝั่ง client), ใส่ JSON Schema ใน prompt และซ่อม JSON ที่ไม่ตรง schema 1 รอบ
ข้อกำหนดของ ThaiLLM ระบุว่าผู้ให้บริการนำข้อมูลที่ส่งไปพัฒนาโมเดลได้ — ตรวจกับนโยบายข้อมูลของหน่วยงานก่อนใช้จริง
ทดสอบการเชื่อมต่อ: `python -m tools.thaillm_smoke`

## โปรไฟล์หน่วยงาน

| โปรไฟล์ | อ้างอิง | เอกสารสำหรับ agent |
| --- | --- | --- |
| `opm` | ระเบียบงานสารบรรณ + นร 0106/ว 2019 และแผ่นแบบ | [`docs/agent.md`](docs/agent.md) |
| `pwa` | + คู่มือการพิมพ์หนังสือ กปภ. (2554) + แม่แบบหนังสือภายใน v5 (2566) | [`docs/profiles/pwa.md`](docs/profiles/pwa.md) |

ค่าการพิมพ์ทุกค่าอยู่ใน `sarabun/style.py` (ค่ากลาง) และ `sarabun/profiles/<ชื่อ>.py` (ค่าเฉพาะหน่วยงาน) พร้อมระบุที่มา
ตรา/โลโก้/แม่แบบของหน่วยงานไม่รวมใน repo — ดู [`references/README.md`](references/README.md)
เพิ่มหน่วยงานใหม่: ดู [CONTRIBUTING.md](CONTRIBUTING.md)

## โครงสร้าง

| ตำแหน่ง | หน้าที่ |
| --- | --- |
| `sarabun/schema.py` | โครงข้อมูลหนังสือ 11 ชนิด (อ้างเลขข้อระเบียบทุก field) |
| `sarabun/style.py` | `LayoutSpec` ค่าการพิมพ์กลางตาม ว 2019 |
| `sarabun/profiles/` | โปรไฟล์หน่วยงาน (`pwa.py`) + ทะเบียนโปรไฟล์ |
| `sarabun/render/docx_renderer.py` | สร้าง .docx: เลขไทย, thaiDistribute, ตราลอย, เลขหน้า, ไฮไลต์ [ระบุ...], กันลายมือชื่อตกหน้า |
| `sarabun/checker.py` | ตรวจเนื้อหาตามระเบียบ + ตรวจไฟล์ .docx |
| `sarabun/salutations.py` | คำขึ้นต้น/ลงท้าย (ภาคผนวก 2 — ชุดที่ใช้บ่อย) |
| `sarabun/llm/` | client OpenAI-compatible, ThaiLLM, ปิดบังข้อมูลส่วนบุคคล, fallback, prompts |
| `sarabun/service.py`, `sarabun/cli.py` | ลำดับงาน 5 ขั้น และบรรทัดคำสั่ง |
| `sarabun/minutes.py` | ถอดเสียงประชุม (faster-whisper) → รายงานการประชุม |
| `api/` | REST API (FastAPI) + หน้าเว็บต้นแบบ |
| `deploy/` | ตัวอย่าง docker-compose แบบติดตั้งภายใน |
| `docs/` | มาตรฐานสำหรับ AI agent (กลาง + รายหน่วยงาน) |
| `examples/`, `tests/`, `tools/` | ตัวอย่างเอกสาร ชุดทดสอบ เครื่องมือเทียบแม่แบบ |

## พัฒนา / ทดสอบ

```bash
pip install -r requirements.txt
python -m pytest -q                          # ไม่ต้องมี GPU หรือ API key (ใช้ MockLLM)
python -m examples.render_samples out/       # สร้างตัวอย่าง .docx ทุกชนิด
uvicorn api.main:app --port 8080             # REST API + หน้าเว็บ
```

ชุดทดสอบเทียบแม่แบบทางการ (`test_official.py`, `test_pwa_template.py`) จะข้ามเองถ้ายังไม่มีไฟล์อ้างอิง — วิธีเตรียมไฟล์ดู `references/README.md`

## ข้อจำกัดที่ทราบ

- ตาราง ภาคผนวก 2 (คำขึ้นต้น/ลงท้าย) ยังไม่ครบทุกฐานะผู้รับ
- ยังไม่ทำ: ตราหน่วยงานหมึกแดงของหนังสือประทับตรา, สำเนาคู่ฉบับ + อักษรย่อผู้ร่าง/พิมพ์/ทาน, รูปถ่ายในหนังสือรับรอง,
  ข้อความต่อเนื่องท้ายหน้า, การปิดบังชื่อบุคคลก่อนส่ง LLM ภายนอก
- ตำแหน่งตราในบันทึกข้อความทดสอบด้วย LibreOffice — ควรตรวจใน Microsoft Word ก่อนใช้งานจริง
- ระบบสร้าง **ร่าง** หนังสือ ผู้มีอำนาจต้องตรวจและลงนามก่อนออกจริง

## สัญญาอนุญาต

- โค้ด: [Apache License 2.0](LICENSE)
- เอกสารใน `docs/`: [CC BY 4.0](LICENSE-docs)
- ตรา/โลโก้ของหน่วยงานและตราครุฑไม่อยู่ในสัญญาอนุญาตนี้ — ดู [NOTICE](NOTICE)

"""PWA profile — คู่มือการพิมพ์หนังสือการประปาส่วนภูมิภาคโดยคอมพิวเตอร์ (งานสารบรรณ กองบริการกลาง ๒๕๕๔)
ต้นฉบับ (ภายใน) private/pwa_manual_2554/ — ดู references/README.md"""
import io
from pathlib import Path

import pytest
from docx import Document
from docx.oxml.ns import qn
from pydantic import ValidationError

from examples.pwa_samples import MEMO_22, PWA_ALL
from sarabun import checker
from sarabun.llm import MockLLM
from sarabun.render import DocxRenderer
from sarabun.render.docx_renderer import text_width_cm
from sarabun.schema import DocType, MemoDoc
from sarabun.service import DraftService, UserProfile
from sarabun.style import DEFAULT_SPEC, PWA_SPEC as P, get_spec

ROOT = Path(__file__).resolve().parent.parent
EMU = 360000.0


def _docx(doc):
    return Document(io.BytesIO(DocxRenderer(P).render(doc)))


def _anchors(d):
    return d.element.body.findall(".//" + qn("wp:anchor")) + d.element.body.findall(".//" + qn("wp:inline"))


def _height_cm(el):
    return int(el.find(qn("wp:extent")).get("cy")) / EMU


def _find(d, start):
    return next(p for p in d.paragraphs if p.text.strip().startswith(start))


def test_profile_registry():
    assert get_spec("pwa") is P and get_spec(None) is DEFAULT_SPEC


@pytest.mark.skipif(not Path(P.emblem_png).exists(), reason="ตรา กปภ. อยู่ใน private/ (ไม่รวมใน repo)")
def test_private_assets_present():
    assert (ROOT / "private/pwa_manual_2554/pwa-old-03.pdf").exists()


def test_emblem_sizes():
    """แบบที่ ๑๒: วงนอก ๒.๘ ซม. (หนังสือภายนอก ฯลฯ) / บันทึกข้อความตามแม่แบบ v5 สูง ๒.๑๘ ซม."""
    for key, cm in (("02_external_letter", 2.8), ("03_stamp_letter", 2.8), ("04_order", 2.8),
                    ("10_certificate", 2.8), ("01_memo", 2.18)):
        hs = [_height_cm(a) for a in _anchors(_docx(PWA_ALL[key]))]
        assert hs and abs(hs[0] - cm) < 0.02, key


def test_no_emblem_news_minutes_3cm():
    """แบบที่ ๙, ๑๑: ไม่มีตรา บรรทัดแรกห่างขอบบน ๓ ซม."""
    for key in ("09_news", "11_minutes"):
        d = _docx(PWA_ALL[key])
        assert not _anchors(d), key
        first = next(p for p in d.paragraphs if p.text.strip())
        top = d.sections[0].top_margin.cm + first.paragraph_format.space_before.cm
        assert abs(top - 3.0) < 0.05, key
        assert "GARUDA" not in {f.rule for f in checker.check_docx(io.BytesIO(DocxRenderer(P).render(PWA_ALL[key])), P)}


def test_memo_unit_word_and_signature():
    d = _docx(PWA_ALL["01_memo"])
    labels = [r for p in d.paragraphs[1:4] for r in p.runs if r.text.strip() in ("หน่วยงาน", "ที่", "วันที่", "เรื่อง")]
    assert len(labels) == 4 and all(r.bold and r.font.size.pt == 20 for r in labels)
    assert not any("ส่วนราชการ" in r.text for p in d.paragraphs[:4] for r in p.runs)
    name = next(p for p in d.paragraphs if p.text.strip().startswith("("))
    assert round(name.paragraph_format.tab_stops[0].position.cm, 2) == P.signature_center_cm   # แม่แบบ: กึ่งกลาง ๙.๕ ซม.


def test_external_closing_on_emblem_center():
    """แบบที่ ๑: ๒ Enter → คำลงท้ายเริ่มที่แนวกึ่งกลางตรา → ๔ Enter → ชื่อ/ตำแหน่งกึ่งกลางกับคำลงท้าย"""
    d = _docx(PWA_ALL["02_external_letter"])
    ps = d.paragraphs
    i = next(k for k, p in enumerate(ps) if p.text.strip() == "ขอแสดงความนับถือ")
    assert not ps[i - 1].text.strip()
    assert round(ps[i].paragraph_format.left_indent.cm, 2) == P.center_cm
    assert all(not ps[i + k].text.strip() for k in (1, 2, 3))
    tab = ps[i + 4].paragraph_format.tab_stops[0].position.cm
    expect = P.center_cm + text_width_cm("ขอแสดงความนับถือ") / 2
    assert abs(tab - expect) < 0.02
    agency = _find(d, "ที่ ")
    assert round(agency.paragraph_format.tab_stops[0].position.cm, 1) == P.agency_tab_cm


def test_order_layout():
    """แบบที่ ๔: ชื่อเรื่องไม่หนา, ย่อหน้าแรก +๖ ที่เหลือ ๑ Enter, สั่ง ณ วันที่ ที่ ๖ ซม. หลัง ๒ Enter, "(" ที่ ๘ ซม."""
    d = _docx(PWA_ALL["04_order"])
    title = _find(d, "คำสั่ง")
    assert not any(r.bold for r in title.runs)
    body = [p for p in d.paragraphs if p.paragraph_format.first_line_indent is not None
            and round(p.paragraph_format.first_line_indent.cm, 1) == 2.5]
    assert body[0].paragraph_format.space_before.pt == 6
    assert all(p.paragraph_format.space_before.pt == 0 for p in body[1:-1])
    assert body[-1].text.startswith("ทั้งนี้") and body[-1].paragraph_format.space_before.pt == 6
    ps = d.paragraphs
    k = next(i for i, p in enumerate(ps) if p.text.strip().startswith("สั่ง"))
    assert not ps[k - 1].text.strip() and round(ps[k].paragraph_format.left_indent.cm, 1) == 6.0
    assert "พ.ศ." in ps[k].text
    name = next(p for p in ps[k:] if p.text.strip().startswith("("))
    assert round(name.paragraph_format.left_indent.cm, 1) == 8.0


def test_statement_issuer_right_of_center():
    d = _docx(PWA_ALL["08_statement"])
    p = next(p for p in reversed(d.paragraphs) if p.paragraph_format.left_indent
             and round(p.paragraph_format.left_indent.cm, 1) == 10.0)
    assert p.text.strip() == "การประปาส่วนภูมิภาค"


def test_stamp_initials_and_certificate():
    d = _docx(PWA_ALL["03_stamp_letter"])
    assert any("(ลงชื่อย่อกำกับตรา)" in p.text for p in d.paragraphs)
    c = _docx(PWA_ALL["10_certificate"])
    assert _find(c, "ที่ มท") and not any(p.text.strip() == "หนังสือรับรอง" for p in c.paragraphs)


def test_page_number_and_memo_22():
    d = _docx(MEMO_22)
    assert d.sections[0].header.paragraphs[0].text == ""     # แม่แบบ v5: PAGE ล้วน (ไม่มีขีด)
    heads = [p.text for p in d.paragraphs if p.text[:2] in ("๑.", "๒.", "๓.", "๔.", "๕.")]
    assert [h.split(".\t")[1] for h in heads] == ["เรื่องเดิม", "ข้อเท็จจริง", "ข้อกฎหมาย", "ข้อพิจารณา", "ข้อเสนอ"]
    with pytest.raises(ValidationError):
        MemoDoc(department="x", doc_no="มท 1/1", date="1 มกราคม 2569", subject="x", to="x")


def test_pwa_checker_rules():
    memo = PWA_ALL["01_memo"].model_copy(update={"date": "3 ตุลาคม พ.ศ. 2569", "doc_no": "กปภ 1/2",
                                                  "department": "ส่วนราชการ กอง ก โทร. 1"})
    order = PWA_ALL["04_order"].model_copy(update={"date": "21 ตุลาคม 2569"})
    r_memo = {f.rule for f in checker.check_document(memo, P)}
    assert {"PWA_DATE_NO_BE", "PWA_DOC_NO", "PWA_UNIT_WORD"} <= r_memo
    assert "PWA_DATE_BE" in {f.rule for f in checker.check_document(order, P)}
    assert not any(f.rule.startswith("PWA") for f in checker.check_document(memo))   # profile opm ไม่ใช้กฎ กปภ.
    for k, doc in PWA_ALL.items():
        assert not any(f.rule.startswith("PWA") for f in checker.check_document(doc, P)), k


def test_pwa_rendered_docx_clean(tmp_path):
    for k, doc in PWA_ALL.items():
        p = tmp_path / f"{k}.docx"
        DocxRenderer(P).render_to(doc, p)
        rules = {f.rule for f in checker.check_docx(p, P)}
        assert not rules & {"MARGIN", "FONT", "GARUDA", "MEMO_TITLE", "MEMO_LABEL"}, (k, rules)


def test_service_uses_pwa_rules():
    draft = PWA_ALL["01_memo"].model_dump(mode="json")
    llm = MockLLM([draft])
    svc = DraftService(llm, DocxRenderer(P))
    svc.draft("ขออนุมัติจัดอบรม", DocType.MEMO, UserProfile())
    assert "คู่มือการพิมพ์หนังสือของการประปาส่วนภูมิภาค" in llm.calls[0][0]
    assert UserProfile().doc_no_prefix.startswith("มท")

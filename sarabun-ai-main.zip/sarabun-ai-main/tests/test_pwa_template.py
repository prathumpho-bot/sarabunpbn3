"""Conformance — บันทึกข้อความของ PWA_SPEC ต้องตรงกับแม่แบบปัจจุบันของ กปภ.
private/pwa_template/แบบหนังสือภายใน_v5.docx — เอกสารภายใน (ค่าทุกตัวอ่านจาก XML ของแม่แบบ ไม่ได้พิมพ์ตัวเลขซ้ำในเทสต์)"""
import io
import re
import zipfile
from pathlib import Path

import pytest
from docx import Document
from docx.oxml.ns import qn

from examples.pwa_samples import MEMO_22, PWA_ALL
from sarabun.render import DocxRenderer
from sarabun.style import PWA_SPEC as P

TPL = Path(__file__).resolve().parent.parent / "private/pwa_template/แบบหนังสือภายใน_v5.docx"
pytestmark = pytest.mark.skipif(not TPL.exists() or not Path(P.emblem_png).exists(),
                                reason="ต้องมีแม่แบบและตรา กปภ. (เอกสารภายใน) ใน private/ — ดู references/README.md")
TW, EMU = 567.0, 360000.0


def _xml(part="word/document.xml"):
    return zipfile.ZipFile(TPL).read(part).decode()


def _paras(x):
    return re.findall(r"<w:p[ >].*?</w:p>", x, re.S)


def _ours(doc=None):
    return Document(io.BytesIO(DocxRenderer(P).render(doc or PWA_ALL["01_memo"])))


def test_page_setup_and_font():
    x = _xml()
    mar = re.search(r"<w:pgMar ([^>]*)/>", x).group(1)
    v = dict(re.findall(r'w:(\w+)="(-?\d+)"', mar))
    sec = _ours().sections[0]
    assert abs(sec.top_margin.cm - int(v["top"]) / TW) < 0.02
    assert abs(sec.left_margin.cm - int(v["left"]) / TW) < 0.02
    assert abs(sec.right_margin.cm - int(v["right"]) / TW) < 0.02
    assert abs(sec.header_distance.cm - int(v["header"]) / TW) < 0.02
    assert 'w:cs="TH SarabunIT๙"' in x and P.font == "TH SarabunIT๙"


def test_title_line():
    head = _paras(_xml())[0]
    sp = dict(re.findall(r'w:(before|after|line)="(\d+)"', re.search(r"<w:spacing [^>]*/>", head).group(0)))
    tabs = [int(t) for t in re.findall(r'<w:tab w:val="left" w:pos="(\d+)"/>', head)]
    p = _ours().paragraphs[0]
    pf = p.paragraph_format
    assert pf.space_before.pt == int(sp["before"]) / 20 and pf.space_after.pt == int(sp["after"]) / 20
    assert pf.line_spacing.pt == int(sp["line"]) / 20
    assert [round(t.position.cm, 2) for t in pf.tab_stops] == [round(t / TW, 2) for t in tabs]
    title = next(r for r in p.runs if "บันทึกข้อความ" in r.text)
    assert title.bold and title.font.size.pt == 29
    assert title._element.rPr.find(qn("w:spacing")).get(qn("w:val")) == "-20"


def test_emblem_position_and_size():
    head = _paras(_xml())[0]
    an = re.search(r'<wp:positionH relativeFrom="margin"><wp:posOffset>(-?\d+)</wp:posOffset></wp:positionH>'
                   r'<wp:positionV relativeFrom="paragraph"><wp:posOffset>(-?\d+)</wp:posOffset></wp:positionV>'
                   r'<wp:extent cx="(\d+)" cy="(\d+)"/>', head)
    x0, y0, cx, cy = map(int, an.groups())
    ours = _ours().element.body.find(".//" + qn("wp:anchor"))
    assert int(ours.find(qn("wp:positionH")).find(qn("wp:posOffset")).text) == x0
    assert int(ours.find(qn("wp:positionV")).find(qn("wp:posOffset")).text) == y0
    ext = ours.find(qn("wp:extent"))
    assert abs(int(ext.get("cy")) - cy) / EMU < 0.02 and abs(int(ext.get("cx")) - cx) / EMU < 0.05


def test_label_lines():
    ps = _paras(_xml())
    unit_tab = int(re.search(r'w:pos="(\d+)"', ps[1]).group(1))
    date_tab = int(re.search(r'w:pos="(\d+)"', ps[2]).group(1))
    d = _ours()
    unit, no = d.paragraphs[1], d.paragraphs[2]
    assert abs(unit.paragraph_format.tab_stops[0].position.cm - unit_tab / TW) < 0.02
    assert abs(no.paragraph_format.tab_stops[0].position.cm - date_tab / TW) < 0.02
    assert "\tโทร" in unit.text                                  # โทร แยกไปที่แท็บ ๑๐.๒ ซม.
    for p in d.paragraphs[1:4]:
        r = p.runs[0]
        assert r.bold and r.font.size.pt == 20
    sal = _paras(_xml())[4]
    assert 'w:before="120"' in sal and 'w:left="720"' in sal and 'w:hanging="720"' in sal


def test_signature_center_tab():
    sig = next(p for p in _paras(_xml()) if "ชื่อ นามสกุล" in p)
    pos = int(re.search(r'w:val="center" w:pos="(\d+)"', sig).group(1))
    name = next(p for p in _ours().paragraphs if p.text.strip().startswith("("))
    assert abs(name.paragraph_format.tab_stops[0].position.cm - pos / TW) < 0.02


def test_memo_22_headings():
    x = _xml()
    lvl = re.search(r'<w:numFmt w:val="thaiNumbers"/><w:lvlText w:val="%1."/>.*?<w:ind w:left="(\d+)" w:hanging="(\d+)"/>',
                    _xml("word/numbering.xml"), re.S)
    left, hang = (int(v) / TW for v in lvl.groups())
    first = int(re.search(r'<w:ind w:firstLine="(\d+)"/>', x).group(1)) / TW
    d = _ours(MEMO_22)
    ps = d.paragraphs
    i = next(k for k, p in enumerate(ps) if p.text.startswith("๑."))
    h = ps[i]
    assert abs(h.paragraph_format.left_indent.cm - left) < 0.05
    assert abs(-h.paragraph_format.first_line_indent.cm - hang) < 0.05
    body = ps[i + 1]
    assert abs(body.paragraph_format.first_line_indent.cm - first) < 0.02


def test_footer_logo():
    f = re.search(r'<wp:extent cx="(\d+)" cy="(\d+)"/>', _xml("word/footer1.xml"))
    cx = int(f.group(1)) / EMU
    d = _ours()
    for part in (d.sections[0].first_page_footer, d.sections[0].footer):
        shp = part.paragraphs[0]._p.find(".//" + qn("wp:extent"))
        assert shp is not None and abs(int(shp.get("cx")) / EMU - cx) < 0.02
    assert d.sections[0].different_first_page_header_footer

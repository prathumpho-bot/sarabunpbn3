"""ThaiLLM API client — ทดสอบด้วย httpx.MockTransport (ไม่เรียกเครือข่ายจริง)"""
import json

import httpx
import pytest

from examples.pwa_samples import PWA_ALL
from sarabun.llm import (FallbackLLM, LLMError, MockLLM, PIIMasker, PrivacyGuardLLM, RateLimiter, ThaiLLM,
                         llm_from_env)
from sarabun.llm.client import parse_json
from sarabun.render import DocxRenderer
from sarabun.schema import DocType
from sarabun.service import DraftService, ExternalLLMNotAllowed, UserProfile
from sarabun.style import PWA_SPEC

MEMO = PWA_ALL["01_memo"].model_dump(mode="json")


def _reply(content, status=200, headers=None):
    return httpx.Response(status, json={"choices": [{"message": {"content": content}}]}, headers=headers)


def _client(handler, **kw):
    return ThaiLLM(api_key="k-test", transport=httpx.MockTransport(handler), sleep=lambda s: None,
                   rate_limiter=None, **kw)


def test_request_shape(monkeypatch):
    seen = {}

    def h(req):
        seen.update(url=str(req.url), auth=req.headers["authorization"], body=json.loads(req.content))
        return _reply("<think>วางแผน</think>\n```json\n" + json.dumps(MEMO, ensure_ascii=False) + "\n```")

    out = _client(h).chat_json("ระบบ", "ร่างบันทึก", schema={"type": "object"})
    assert seen["url"] == "https://thaillm.or.th/api/v1/chat/completions"
    assert seen["auth"] == "Bearer k-test"
    assert seen["body"]["model"] == "Typhoon-S-ThaiLLM-8B-Instruct"
    assert "response_format" not in seen["body"]                       # โหมด prompt
    assert "JSON Schema" in seen["body"]["messages"][0]["content"]
    assert out["subject"] == MEMO["subject"]


def test_env_config(monkeypatch):
    monkeypatch.setenv("THAILLM_API_KEY", "abc")
    monkeypatch.setenv("THAILLM_BASE_URL", "http://thaillm.or.th/api/v1/")
    monkeypatch.setenv("THAILLM_MODEL", "Pathumma-ThaiLLM-qwen3-8b-think-3.0.0")
    llm = llm_from_env("thaillm")
    assert isinstance(llm, PrivacyGuardLLM) and llm.external
    assert llm.info()["base_url"] == "https://thaillm.or.th/api/v1"      # http → https (API key ไม่ส่งแบบไม่เข้ารหัส)
    assert llm.info()["model"].startswith("Pathumma")
    chain = llm_from_env("thaillm+onprem")
    assert isinstance(chain, FallbackLLM) and [x["provider"] for x in chain.info()["chain"]] == ["thaillm", "onprem"]
    monkeypatch.delenv("THAILLM_API_KEY")
    with pytest.raises(ValueError):
        llm_from_env("thaillm")


def test_json_schema_downgrade():
    calls = []

    def h(req):
        b = json.loads(req.content)
        calls.append("response_format" in b)
        if "response_format" in b:
            return httpx.Response(400, json={"error": "response_format not supported"})
        return _reply('ได้เลยครับ {"a": "x}y", "b": [1, {"c": 2}]} หวังว่าจะช่วยได้')

    llm = _client(h, structured="json_schema")
    assert llm.chat_json("s", "u", schema={"type": "object"}) == {"a": "x}y", "b": [1, {"c": 2}]}
    assert calls == [True, False] and llm.structured == "prompt"


def test_retry_429_and_auth_error():
    n = {"i": 0}

    def h(req):
        n["i"] += 1
        return _reply('{"ok": 1}') if n["i"] == 3 else httpx.Response(429, headers={"retry-after": "1"})

    assert _client(h).chat_json("s", "u") == {"ok": 1} and n["i"] == 3
    with pytest.raises(LLMError, match="API key"):
        _client(lambda r: httpx.Response(401)).chat_json("s", "u")


def test_json_repair_turn():
    replies = iter(["ขออภัย ไม่สามารถ", '{"x": 1}'])
    assert _client(lambda r: _reply(next(replies))).chat_json("s", "u") == {"x": 1}


def test_rate_limiter():
    t = {"now": 0.0}
    slept = []

    def sleep(s):
        slept.append(round(s, 3))
        t["now"] += s

    rl = RateLimiter(per_second=5, per_minute=3, clock=lambda: t["now"], sleep=sleep)
    for _ in range(4):
        rl.wait()
    assert slept[:2] == [0.2, 0.2] and slept[-1] > 59        # ๕/วินาที แล้วครบโควตา/นาที


def test_pii_masked_before_sending():
    sent = {}

    def h(req):
        sent["text"] = json.loads(req.content)["messages"][1]["content"]
        return _reply('{"to": "ติดต่อ ⟦P1⟧ หรือ ⟦P2⟧"}')

    guard = PrivacyGuardLLM(_client(h))
    out = guard.chat_json("s", "ติดต่อ 081-234-5678 หรือ somchai@pwa.co.th บัตร 1-1004-00123-45-6")
    assert "081" not in sent["text"] and "somchai" not in sent["text"] and "1004" not in sent["text"]
    assert out["to"] == "ติดต่อ 081-234-5678 หรือ somchai@pwa.co.th"
    m = PIIMasker()
    keep = "ที่ มท 551234/123 วันที่ ๒๑ ตุลาคม ๒๕๖๙ จำนวน ๑๒,๕๐๐ บาท"
    assert m.mask(keep) == keep                                      # ไม่ปิดบังเลขที่หนังสือ/วันที่/จำนวนเงิน


def test_fallback_to_onprem():
    bad = _client(lambda r: httpx.Response(503))
    good = MockLLM([{"ok": True}])
    chain = FallbackLLM(bad, good)
    assert chain.chat_json("s", "u") == {"ok": True} and chain.last_used is good


def test_secret_docs_never_sent_external():
    def h(req):
        raise AssertionError("ต้องไม่ถูกเรียก")

    svc = DraftService(PrivacyGuardLLM(_client(h)), DocxRenderer(PWA_SPEC))
    with pytest.raises(ExternalLLMNotAllowed):
        svc.draft("เรื่องลับ", DocType.MEMO, UserProfile(), secrecy="ลับ")
    secret = PWA_ALL["01_memo"].model_copy(update={"secrecy": "ลับมาก"})
    with pytest.raises(ExternalLLMNotAllowed):
        svc.revise(secret, "แก้คำ")


def test_service_repairs_invalid_json_from_small_model():
    bad = dict(MEMO)
    bad.pop("subject")
    llm = MockLLM([bad, MEMO])
    doc = DraftService(llm, DocxRenderer(PWA_SPEC)).draft("ขออนุมัติ", DocType.MEMO, UserProfile())
    assert doc.subject == MEMO["subject"]
    assert "subject" in llm.calls[1][1] and "ไม่ตรง schema" in llm.calls[1][1]


def test_parse_json_variants():
    assert parse_json('<think>{"no": 1}</think>{"yes": 2}') == {"yes": 2}
    assert parse_json('```json\n{"a": "b"}\n```') == {"a": "b"}
    with pytest.raises(ValueError):
        parse_json('{"a": ')


def test_secret_docs_route_to_onprem_in_chain():
    def h(req):
        raise AssertionError("ThaiLLM ต้องไม่ถูกเรียก")

    onprem = MockLLM([MEMO])
    svc = DraftService(FallbackLLM(PrivacyGuardLLM(_client(h)), onprem), DocxRenderer(PWA_SPEC))
    doc = svc.draft("เรื่องลับ", DocType.MEMO, UserProfile(), secrecy="ลับ")
    assert doc.secrecy == "ลับ" and len(onprem.calls) == 1


def test_shorthand_models_and_apikey_header(monkeypatch):
    from sarabun.llm import resolve_model
    assert resolve_model("openthaigpt") == "OpenThaiGPT-ThaiLLM-8B-Instruct-v7.2"
    assert resolve_model("KBTG") == resolve_model("thalle") == "THaLLE-0.2-ThaiLLM-8B-fa"
    assert resolve_model("typhoon-s-thaillm-8b-instruct") == "Typhoon-S-ThaiLLM-8B-Instruct"
    assert resolve_model("qwen3.6-35b-a3b") == "qwen3.6-35b-a3b"          # ชื่อนอกเอกสารส่งตามเดิม
    seen = {}

    def h(req):
        seen.update(headers=dict(req.headers), model=json.loads(req.content)["model"])
        return _reply('{"ok": 1}')

    _client(h, model="pathumma", auth_header="apikey").chat_json("s", "u")
    assert seen["headers"]["apikey"] == "k-test" and "authorization" not in seen["headers"]
    assert seen["model"] == "Pathumma-ThaiLLM-qwen3-8b-think-3.0.0"
    monkeypatch.setenv("THAILLM_ALLOW_HTTP", "1")
    assert ThaiLLM(api_key="k", base_url="http://thaillm.or.th/api/v1").base_url.startswith("http://")


def test_official_rate_limits_are_ceiling(monkeypatch):
    monkeypatch.setenv("THAILLM_RPS", "50")
    monkeypatch.setenv("THAILLM_RPM", "1000")
    rl = ThaiLLM(api_key="k").rate_limiter
    assert (rl.per_second, rl.per_minute) == (5, 200)
    monkeypatch.setenv("THAILLM_RPS", "2")
    assert ThaiLLM(api_key="k").rate_limiter.per_second == 2

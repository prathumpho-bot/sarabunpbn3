"""python -m sarabun — ส่วนสร้างเอกสารอย่างเดียว (ThaiLLM จำลองด้วย MockTransport)"""
import json

import httpx
from docx import Document

from examples.pwa_samples import PWA_ALL
from sarabun import cli
from sarabun.llm import PrivacyGuardLLM, ThaiLLM

MEMO = PWA_ALL["01_memo"].model_dump(mode="json")


def _fake_thaillm(replies):
    it = iter(replies)
    sent = []

    def h(req):
        sent.append(json.loads(req.content))
        return httpx.Response(200, json={"choices": [{"message": {"content": json.dumps(next(it), ensure_ascii=False)}}]})

    llm = PrivacyGuardLLM(ThaiLLM(api_key="k", transport=httpx.MockTransport(h), rate_limiter=None, sleep=lambda s: None))
    return llm, sent


def test_cli_draft_with_thaillm(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("THAILLM_MODEL", "typhoon")              # ให้ monkeypatch คืนค่าหลังเทสต์
    llm, sent = _fake_thaillm([{"doc_type": "memo", "reason": "ภายใน กปภ."}, MEMO])
    monkeypatch.setattr(cli, "llm_from_env", lambda provider: llm)
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.json").write_text(json.dumps({"department": "กองบริหารระบบข้อมูลสารสนเทศ",
                                                       "signer_name": "นายทดสอบ ระบบ"}, ensure_ascii=False))
    rc = cli.main(["ขออนุมัติจัดอบรม โทร 081-234-5678", "-o", "out.docx", "--json-out", "draft.json",
                   "--profile-file", "profile.json", "--model", "openthaigpt"])
    assert rc == 0 and (tmp_path / "out.docx").exists() and (tmp_path / "draft.json").exists()
    assert "081-234-5678" not in json.dumps(sent, ensure_ascii=False)          # ปิดบังก่อนส่ง
    assert "บันทึกข้อความ" in Document(str(tmp_path / "out.docx")).paragraphs[0].text
    out = capsys.readouterr()
    assert "สร้างไฟล์ out.docx" in out.out and "ชนิดที่แนะนำ: บันทึกข้อความ" in out.err


def test_cli_render_from_json_without_llm(tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "llm_from_env", lambda p: (_ for _ in ()).throw(AssertionError("ห้ามเรียก LLM")))
    (tmp_path / "d.json").write_text(json.dumps(MEMO, ensure_ascii=False), encoding="utf-8")
    assert cli.main(["--from-json", str(tmp_path / "d.json"), "-o", str(tmp_path / "x.docx")]) == 0
    assert (tmp_path / "x.docx").exists()


def test_cli_secret_refused_and_missing_key(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("THAILLM_API_KEY", raising=False)
    assert cli.main(["x", "-t", "memo"]) == 2                                   # ไม่มี API key
    llm, sent = _fake_thaillm([])
    monkeypatch.setattr(cli, "llm_from_env", lambda p: llm)
    assert cli.main(["x", "-t", "memo", "--secrecy", "ลับ"]) == 3 and not sent


def test_dotenv(tmp_path, monkeypatch):
    monkeypatch.delenv("THAILLM_API_KEY", raising=False)
    monkeypatch.setenv("THAILLM_MODEL", "typhoon")
    monkeypatch.setenv("THAILLM_API_KEY", "x")
    monkeypatch.delenv("THAILLM_API_KEY")
    (tmp_path / ".env").write_text("THAILLM_API_KEY=abc123  # คีย์\nTHAILLM_MODEL=pathumma\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    cli.load_dotenv()
    import os
    assert os.environ["THAILLM_API_KEY"] == "abc123"
    assert os.environ["THAILLM_MODEL"] == "typhoon"                           # ไม่ทับค่าที่ตั้งไว้แล้ว

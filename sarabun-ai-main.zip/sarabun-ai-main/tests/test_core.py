import io
import json
from datetime import date

from docx import Document
from docx.oxml.ns import qn
from fastapi.testclient import TestClient

from examples.samples import ALL, CERTIFICATE, EXTERNAL, MEMO, ORDER, REGULATION
from sarabun import checker
from sarabun.llm import MockLLM
from sarabun.render import DocxRenderer
from sarabun.schema import DocType
from sarabun.service import DraftService, UserProfile
from sarabun.style import DEFAULT_SPEC
from sarabun.thai_utils import thai_date, to_thai_digits


def _docx(doc):
    return Document(io.BytesIO(DocxRenderer().render(doc)))


def test_thai_digits_skip_email():
    assert to_thai_digits("จำนวน 50 คน a1@pwa.co.th") == "จำนวน ๕๐ คน a1@pwa.co.th"
    assert thai_date(date(2026, 10, 3)) == "๓ ตุลาคม ๒๕๖๙"


def test_render_all_11_types():
    assert len(ALL) == 11
    for name, doc in ALL.items():
        d = _docx(doc)
        sec = d.sections[0]
        assert round(sec.left_margin.cm, 1) == 3.0 and round(sec.right_margin.cm, 1) == 2.0, name
        assert round(sec.top_margin.cm, 1) == 1.5, name
        text = "\n".join(p.text for p in d.paragraphs)
        assert not any(ch in text for ch in "0123456789") or "@" in text, name
        if not name.endswith("minutes"):
            pics = d.inline_shapes or d.element.body.findall(".//" + qn("wp:anchor"))
            assert pics, f"{name}: missing garuda"


def test_w2019_spacing_external():
    """ว ๒๐๑๙: ภาคต่าง ๆ Before ๖ pt / คำลงท้าย Before ๑๒ pt / ลงชื่อหลัง ๔ Enter / ส่วนราชการเจ้าของเรื่องหลัง ๔ Enter"""
    d = _docx(EXTERNAL)
    ps = d.paragraphs
    idx = {p.text.strip(): i for i, p in enumerate(ps)}
    closing = ps[idx["ขอแสดงความนับถือ"]]
    assert closing.paragraph_format.space_before.pt == 12
    i = idx["ขอแสดงความนับถือ"]
    assert all(not ps[i + k].text.strip() for k in (1, 2, 3)) and ps[i + 4].text.strip().startswith("(")
    j = next(k for k, p in enumerate(ps) if p.text.strip().startswith("ผู้ว่าการ"))
    assert all(not ps[j + k].text.strip() for k in (1, 2, 3)) and "กองบริหาร" in ps[j + 4].text
    body = [p for p in ps if p.paragraph_format.first_line_indent and
            round(p.paragraph_format.first_line_indent.cm, 1) == 2.5]
    assert body and all(p.paragraph_format.space_before.pt == 6 for p in body)


def test_w2019_memo_header():
    d = _docx(MEMO)
    title = d.paragraphs[0]
    run = next(r for r in title.runs if "บันทึกข้อความ" in r.text)
    assert run.bold and run.font.size.pt == 29
    assert title.paragraph_format.line_spacing.pt == 35
    labels = [r for p in d.paragraphs[1:4] for r in p.runs if r.text.strip() in ("ส่วนราชการ", "ที่", "วันที่", "เรื่อง")]
    assert len(labels) == 4 and all(r.bold and r.font.size.pt == 20 for r in labels)
    assert DEFAULT_SPEC.font == "TH SarabunPSK"


def test_speed_red_32():
    d = _docx(EXTERNAL)
    r = next(r for p in d.paragraphs for r in p.runs if r.text == "ด่วน")
    assert r.bold and r.font.size.pt >= 32 and str(r.font.color.rgb) == "FF0000"


def test_checker_flags():
    bad = MEMO.model_copy(deep=True)
    bad.date, bad.doc_no = "10/03/2026", "กปภ123"
    bad.body.purpose = []
    rules = {f.rule for f in checker.check_document(bad)}
    assert {"DATE_FORMAT", "DOC_NO", "BODY_PURPOSE", "PLACEHOLDER"} <= rules


def test_checker_type_rules():
    o = ORDER.model_copy(update={"doc_no": "123"})
    assert "ORDER_NO" in {f.rule for f in checker.check_document(o)}
    r = REGULATION.model_copy(deep=True)
    r.articles = r.articles[:2]
    assert "REG_ARTICLES" in {f.rule for f in checker.check_document(r)}
    by = REGULATION.model_copy(update={"doc_type": DocType.BYLAW, "preamble": "โดยที่เป็นการสมควร"})
    assert {"BYLAW_AUTHORITY", "REG_WORD"} <= {f.rule for f in checker.check_document(by)}
    c = CERTIFICATE.model_copy(update={"body": ["ขอรับรองว่า นาย ก"]})
    assert "CERT_OPENING" in {f.rule for f in checker.check_document(c)}


def test_salutation_pair():
    bad = EXTERNAL.model_copy(deep=True)
    bad.salutation, bad.closing = "กราบเรียน", "ขอแสดงความนับถือ"
    assert "SALUTATION_PAIR" in {f.rule for f in checker.check_document(bad)}


def test_checker_on_rendered_docx(tmp_path):
    for doc in (MEMO, EXTERNAL):
        p = tmp_path / "x.docx"
        DocxRenderer().render_to(doc, p)
        rules = {f.rule for f in checker.check_docx(p)}
        assert not rules & {"MARGIN", "FONT", "GARUDA", "MEMO_TITLE", "MEMO_LABEL"}, rules


def test_service_pipeline_with_mock_llm():
    draft = EXTERNAL.model_dump(mode="json")
    draft["salutation"], draft["closing"] = "เรียน", "ขอแสดงความนับถืออย่างยิ่ง"
    draft["to"] = "เรียน นายกรัฐมนตรี"
    llm = MockLLM([{"doc_type": "external_letter", "reason": "ข้อ ๑๑"}, draft])
    svc = DraftService(llm)
    assert svc.classify("ขอเชิญวิทยากร")["doc_type"] == "external_letter"
    doc = svc.draft("ขอเชิญวิทยากร", DocType.EXTERNAL_LETTER, UserProfile())
    assert doc.to == "นายกรัฐมนตรี"
    assert (doc.salutation, doc.closing) == ("กราบเรียน", "ขอแสดงความนับถืออย่างยิ่ง")
    assert "ข้อ ๑๑" in llm.calls[1][0]          # prompt มีโครงตามข้อ ๑๑
    assert svc.render(doc)[:2] == b"PK"


def test_api_render_and_check():
    from api.main import app
    c = TestClient(app)
    assert len(c.get("/api/doc-types").json()) == 11
    for doc in ALL.values():
        body = json.loads(doc.model_dump_json())
        r = c.post("/api/render", json=body)
        assert r.status_code == 200 and r.content[:2] == b"PK"
        assert c.post("/api/check", json=body).status_code == 200

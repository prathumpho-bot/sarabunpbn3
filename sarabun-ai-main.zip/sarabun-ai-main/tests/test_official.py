"""Conformance tests — ค่าการพิมพ์ของ SARABUN.AI ต้องตรงกับแผ่นแบบ (template) ทางการของสำนักนายกรัฐมนตรี
ที่แนบกับหนังสือ นร ๐๑๐๖/ว ๒๐๑๙ (references/opm_w2019/template_*.docx แปลงจาก .doc ต้นฉบับด้วย LibreOffice)"""
import io
import re
import zipfile
from pathlib import Path

import pytest
from docx import Document

from examples.official_w2019 import OFFICIAL, OPM_IN, OPM_OUT, OPM_SEAL
from sarabun.render import DocxRenderer
from sarabun.style import DEFAULT_SPEC as S

REF = Path(__file__).resolve().parent.parent / "references" / "opm_w2019"
pytestmark = pytest.mark.skipif(not (REF / "template_in.docx").exists(),
                                reason="ดาวน์โหลดเอกสารต้นฉบับของสำนักนายกรัฐมนตรีตาม references/README.md ก่อน")
TW = 567.0  # twips per cm
EMU = 360000.0


def _xml(name: str) -> str:
    return zipfile.ZipFile(REF / name).read("word/document.xml").decode()


def _paras(xml: str):
    return re.findall(r"<w:p[ >].*?</w:p>", xml, re.S)


def test_reference_files_present():
    for f in ["CN20189.pdf", "Explain_Typing_.pdf", "example_Out.pdf", "example_In.pdf", "example_Seal.pdf",
              "template_Out_.docx", "template_in.docx", "template_seal.docx"]:
        assert (REF / f).exists(), f


@pytest.mark.parametrize("tpl", ["template_Out_.docx", "template_in.docx", "template_seal.docx"])
def test_margins_match_template(tpl):
    sec = Document(str(REF / tpl)).sections[0]
    assert abs(sec.left_margin.cm - S.margin_left_cm) < 0.05
    assert abs(sec.right_margin.cm - S.margin_right_cm) < 0.05
    assert abs(sec.page_width.cm - S.page_w_cm) < 0.05


def test_external_template_values():
    x = _xml("template_Out_.docx")
    # ครุฑ: สูง ๓ ซม. กึ่งกลางที่แนว ๘ ซม.
    off, cx, cy = map(int, re.search(r'positionH relativeFrom="margin"><wp:posOffset>(\d+)</wp:posOffset>.*?'
                                     r'<wp:extent cx="(\d+)" cy="(\d+)"', x, re.S).groups())
    assert abs(cy / EMU - S.garuda_external_cm) < 0.05
    assert abs((off + cx / 2) / EMU - S.center_cm) < 0.1
    # ภาคเหตุ/ความประสงค์/สรุป: ย่อหน้า ๒.๕ ซม. + Before ๖ pt
    body = [p for p in _paras(x) if "firstLine=\"1418\"" in p]
    assert len(body) == 3
    assert all('w:before="120"' in p for p in body)
    assert abs(1418 / TW - S.para_indent_cm) < 0.01 and S.para_before_pt == 120 / 20
    # คำลงท้าย Before ๑๒ pt
    assert 'w:before="240"' in x and S.closing_before_pt == 240 / 20
    # ชื่อ/ตำแหน่ง จัดกึ่งกลางที่แท็บกลาง 5387 twips
    pos = int(re.search(r'w:val="center" w:pos="(\d+)"', x).group(1))
    assert abs(pos / TW - S.signature_center_cm) < 0.01


def test_memo_template_values():
    x = _xml("template_in.docx")
    head = _paras(x)[0]
    assert 'w:lineRule="exact" w:line="700"' in head and S.memo_title_exact_pt == 700 / 20
    assert '<w:szCs w:val="58"/>' in head or '<w:sz w:val="58"/>' in head
    assert S.memo_title_pt == 58 / 2
    cy = int(re.search(r'<wp:extent cx="\d+" cy="(\d+)"', head).group(1))
    assert abs(cy / EMU - S.garuda_memo_cm) < 0.05
    labels = _paras(x)[1:4]
    assert all('w:val="40"' in p for p in labels) and S.memo_label_pt == 40 / 2
    sal = _paras(x)[4]
    assert 'w:before="120"' in sal and 'w:hanging="720"' in sal
    assert abs(720 / TW - S.salutation_hang_cm) < 0.01


def test_seal_template_values():
    x = _xml("template_seal.docx")
    to = next(p for p in _paras(x) if "ถึง" in p)
    assert 'w:before="160"' in to and S.stamp_to_before_pt == 160 / 20


def test_our_render_uses_template_values():
    d = Document(io.BytesIO(DocxRenderer().render(OPM_OUT)))
    body = [p for p in d.paragraphs if p.paragraph_format.first_line_indent is not None
            and round(p.paragraph_format.first_line_indent.cm, 2) == 2.5]
    assert len(body) == 3 and all(p.paragraph_format.space_before.pt == 6 for p in body)
    closing = next(p for p in d.paragraphs if p.text.strip() == "ขอแสดงความนับถือ")
    assert closing.paragraph_format.space_before.pt == 12
    assert round(closing.paragraph_format.tab_stops[0].position.cm, 2) == S.signature_center_cm
    m = Document(io.BytesIO(DocxRenderer().render(OPM_IN)))
    assert m.paragraphs[0].paragraph_format.line_spacing.pt == 35
    sd = Document(io.BytesIO(DocxRenderer().render(OPM_SEAL)))
    to = next(p for p in sd.paragraphs if p.text.startswith("ถึง"))
    assert to.paragraph_format.space_before.pt == 8


def test_official_examples_render():
    for k, doc in OFFICIAL.items():
        assert DocxRenderer().render(doc)[:2] == b"PK", k

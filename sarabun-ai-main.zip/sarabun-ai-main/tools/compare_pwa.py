"""เทียบผลการพิมพ์ PWA_SPEC กับแบบในคู่มือการพิมพ์หนังสือ กปภ. (๒๕๕๔)
python -m tools.compare_pwa samples_out/pwa   (ต้องมี LibreOffice + poppler-utils)"""
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from examples.pwa_samples import PWA_ALL
from sarabun.render import DocxRenderer
from sarabun.style import PWA_SPEC

ROOT = Path(__file__).resolve().parent.parent
MANUAL = ROOT / "private/pwa_manual_2554/pwa-old-03.pdf"    # เอกสารภายใน กปภ.
TEMPLATE = ROOT / "private/pwa_template/แบบหนังสือภายใน_v5.docx"
# หน้าในไฟล์ PDF ของแบบที่ ๑–๑๑ (แบบเปล่าในคู่มือ)
PAGES = {"02_external_letter": 18, "01_memo": 21, "02b_memo_2-2": 24, "03_stamp_letter": 27, "04_order": 30,
         "05_regulation": 33, "06_bylaw": 36, "07_announcement": 39, "08_statement": 42, "09_news": 45,
         "10_certificate": 48, "11_minutes": 51}
H = 1400


def _png(pdf: Path, page: int | None, out: Path) -> Image.Image:
    args = ["pdftoppm", "-scale-to-y", str(H), "-scale-to-x", "-1", "-png", "-singlefile"]
    if page:
        args += ["-f", str(page), "-l", str(page)]
    subprocess.run([*args, str(pdf), str(out)], check=True)
    im = Image.open(f"{out}.png").convert("RGB")
    return im.resize((int(im.width * H / im.height), H))


def main(out_dir: str = "samples_out/pwa"):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    r = DocxRenderer(PWA_SPEC)
    for k, d in PWA_ALL.items():
        r.render_to(d, out / f"{k}.docx")
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", str(out),
                    *map(str, sorted(out.glob("*.docx")))], check=True, capture_output=True)
    try:
        font = ImageFont.truetype(str(Path.home() / ".fonts/THSarabunNew-Bold.ttf"), 40)
    except OSError:
        font = ImageFont.load_default()
    pages = []
    with tempfile.TemporaryDirectory() as tmp:
        # แม่แบบปัจจุบัน (แบบหนังสือภายใน v5) — แปลงเป็น PDF ด้วย LibreOffice
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, str(TEMPLATE)],
                       check=True, capture_output=True)
        tpl_pdf = Path(tmp) / (TEMPLATE.stem + ".pdf")
        items = [(k, "แม่แบบ v5", tpl_pdf, None) for k in ("02b_memo_2-2", "01_memo")]
        items += [(k, f"คู่มือ กปภ. หน้า {pg}", MANUAL, pg) for k, pg in PAGES.items() if k not in ("01_memo", "02b_memo_2-2")]
        for k, label, src, pg in items:
            a = _png(src, pg, Path(tmp) / f"m{k}{pg}")
            b = _png(out / f"{k}.pdf", None, Path(tmp) / f"o{k}")
            o = Image.new("RGB", (a.width + b.width + 60, H + 70), "white")
            dr = ImageDraw.Draw(o)
            o.paste(a, (20, 60))
            o.paste(b, (a.width + 40, 60))
            dr.rectangle([a.width + 40, 60, a.width + 39 + b.width, 59 + H], outline="gray")
            dr.text((20, 10), label, font=font, fill="black")
            dr.text((a.width + 40, 10), f"SARABUN.AI (PWA_SPEC) — {k}", font=font, fill="black")
            o.save(out / f"compare_{k}{'' if pg else '_template'}.png")
            pages.append(o)
    pages[0].save(out / "เทียบคู่มือ_กปภ.pdf", save_all=True, append_images=pages[1:], resolution=110)
    print(out / "เทียบคู่มือ_กปภ.pdf")


if __name__ == "__main__":
    main(*sys.argv[1:])

"""สร้างภาพเทียบ ตัวอย่างทางการ (ซ้าย) กับผลของ SARABUN.AI (ขวา)
python -m tools.compare_official out_dir/     (ต้องมี LibreOffice + pdftoppm และฟอนต์ TH SarabunPSK)"""
import subprocess
import sys
from pathlib import Path

from PIL import Image, ImageDraw

from examples.official_w2019 import OFFICIAL
from sarabun.render import DocxRenderer

REF = Path(__file__).resolve().parent.parent / "references" / "opm_w2019"
PAIRS = {"w2019_letter": "CN20189.pdf", "opm_out": "example_Out.pdf", "opm_in": "example_In.pdf",
         "opm_seal": "example_Seal.pdf"}
LABEL = {"w2019_letter": "หนังสือ ว ๒๐๑๙ ฉบับจริง", "opm_out": "หนังสือภายนอก",
         "opm_in": "หนังสือภายใน", "opm_seal": "หนังสือประทับตรา"}


def page1_png(pdf: Path, stem: Path) -> Image.Image:
    subprocess.run(["pdftoppm", "-r", "90", "-png", "-f", "1", "-l", "1", "-singlefile", str(pdf), str(stem)], check=True)
    return Image.open(f"{stem}.png").convert("RGB")


def main(out: Path):
    out.mkdir(parents=True, exist_ok=True)
    r = DocxRenderer()
    pages = []
    for key, doc in OFFICIAL.items():
        docx = r.render_to(doc, out / f"{key}.docx")
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", str(out), str(docx)],
                       check=True, capture_output=True)
        ours = page1_png(out / f"{key}.pdf", out / f"{key}_ours")
        orig = page1_png(REF / PAIRS[key], out / f"{key}_orig")
        h = 1050
        orig = orig.resize((int(orig.width * h / orig.height), h))
        ours = ours.resize((int(ours.width * h / ours.height), h))
        canvas = Image.new("RGB", (orig.width + ours.width + 30, h + 40), "white")
        canvas.paste(orig, (0, 40))
        canvas.paste(ours, (orig.width + 30, 40))
        d = ImageDraw.Draw(canvas)
        d.text((10, 10), f"Official sample (opm.go.th) - {key}", fill="black")
        d.text((orig.width + 40, 10), "SARABUN.AI render", fill="black")
        canvas.save(out / f"compare_{key}.png")
        pages.append(canvas)
    pages[0].save(out / "compare_official.pdf", save_all=True, append_images=pages[1:])
    print(out / "compare_official.pdf")


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else "compare_out"))

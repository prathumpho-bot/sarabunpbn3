"""ทดสอบเชื่อมต่อ ThaiLLM จริง (ต้องมี THAILLM_API_KEY)
python -m tools.thaillm_smoke                  → รายชื่อโมเดล + ร่างบันทึกข้อความ ๑ ฉบับ → out/thaillm_memo.docx
python -m tools.thaillm_smoke qwen3.6-35b-a3b  → ระบุโมเดล"""
import sys
import time
from pathlib import Path

from sarabun.llm import PrivacyGuardLLM, ThaiLLM
from sarabun.render import DocxRenderer
from sarabun.schema import DocType
from sarabun.service import DraftService, UserProfile
from sarabun.style import PWA_SPEC


def main(model: str | None = None):
    llm = ThaiLLM(model=model)
    print("models:", llm.list_models())
    svc = DraftService(PrivacyGuardLLM(llm), DocxRenderer(PWA_SPEC))
    t = time.time()
    doc = svc.draft("ขออนุมัติจัดอบรมการใช้ระบบร่างหนังสือราชการให้พนักงาน ๕๐ คน วันที่ ๑๐ พฤศจิกายน ๒๕๖๙",
                    DocType.MEMO, UserProfile())
    print(f"{llm.model}: {time.time() - t:.1f} s")
    print(svc.check(doc))
    out = Path("out")
    out.mkdir(exist_ok=True)
    print(svc.renderer.render_to(doc, out / "thaillm_memo.docx"))


if __name__ == "__main__":
    main(*sys.argv[1:])

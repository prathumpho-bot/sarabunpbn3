"""สร้างฟอนต์สำหรับ 'พรีวิว' บนเซิร์ฟเวอร์ที่ไม่มี TH SarabunPSK (เช่น ใน CI/LibreOffice headless)
ปรับขนาดและระยะบรรทัดของ TH Sarabun New ให้ใกล้ TH SarabunPSK ในเอกสารจริง (กว้าง ~0.69, บรรทัด ~1.07 em)
แล้วตั้งชื่อ family เป็น 'TH SarabunPSK' — ใช้ตรวจการตัดหน้า/ตัดบรรทัดเท่านั้น ห้ามใช้แทนฟอนต์จริงในเอกสารที่ส่งออก
python -m tools.make_preview_font THSarabunNew.ttf THSarabunNew-Bold.ttf  → ~/.fonts/preview-THSarabunPSK-*.ttf"""
import sys
from pathlib import Path

from fontTools.ttLib import TTFont


def patch(src: str, style: str, width=0.69, asc=0.80, desc=0.27, family: str = "TH SarabunPSK"):
    t = TTFont(src)
    upm = int(round(t["head"].unitsPerEm / width))
    t["head"].unitsPerEm = upm
    a, d = int(asc * upm), int(desc * upm)
    t["hhea"].ascent, t["hhea"].descent, t["hhea"].lineGap = a, -d, 0
    o = t["OS/2"]
    o.usWinAscent, o.usWinDescent, o.sTypoAscender, o.sTypoDescender, o.sTypoLineGap = a, d, a, -d, 0
    for rec in t["name"].names:
        if rec.nameID in (1, 16):
            rec.string = family
        elif rec.nameID == 4:
            rec.string = family + ("" if style == "Regular" else " Bold")
        elif rec.nameID == 6:
            rec.string = family.replace(" ", "").replace("๙", "9") + ("" if style == "Regular" else "-Bold")
    tag = family.replace(" ", "").replace("๙", "9")
    out = Path.home() / ".fonts" / f"preview-{tag}-{style}.ttf"
    out.parent.mkdir(exist_ok=True)
    t.save(out)
    return out


if __name__ == "__main__":
    # ฟอนต์พรีวิวทั้ง TH SarabunPSK (ว ๒๐๑๙) และ TH SarabunIT๙ (แม่แบบ กปภ.)
    for fam in ("TH SarabunPSK", "TH SarabunIT๙"):
        print(patch(sys.argv[1], "Regular", family=fam))
        if len(sys.argv) > 2:
            print(patch(sys.argv[2], "Bold", family=fam))

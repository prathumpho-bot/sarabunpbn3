"""Structured document models — โครงตามระเบียบสำนักนายกรัฐมนตรีว่าด้วยงานสารบรรณ พ.ศ. ๒๕๒๖
และที่แก้ไขเพิ่มเติม (ฉบับที่ ๒ พ.ศ. ๒๕๔๘ ... ฉบับที่ ๔ พ.ศ. ๒๕๖๔).

ลำดับ field ในแต่ละ model = ลำดับส่วนประกอบตามข้อของระเบียบ (อ้างไว้ใน docstring)
LLM เติมเฉพาะ field; renderer จัดรูปแบบตามแนวทาง นร ๐๑๐๖/ว ๒๐๑๙
"""
from __future__ import annotations

from enum import Enum
from typing import Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator


class DocType(str, Enum):
    MEMO = "memo"                        # หนังสือภายใน / บันทึกข้อความ  (ข้อ ๑๒)
    EXTERNAL_LETTER = "external_letter"  # หนังสือภายนอก               (ข้อ ๑๑)
    STAMP_LETTER = "stamp_letter"        # หนังสือประทับตรา             (ข้อ ๑๓–๑๔)
    ORDER = "order"                      # คำสั่ง                      (ข้อ ๑๖)
    REGULATION = "regulation"            # ระเบียบ                     (ข้อ ๑๗)
    BYLAW = "bylaw"                      # ข้อบังคับ                    (ข้อ ๑๘)
    ANNOUNCEMENT = "announcement"        # ประกาศ / แจ้งความ            (ข้อ ๒๐)
    STATEMENT = "statement"              # แถลงการณ์                   (ข้อ ๒๑)
    NEWS = "news"                        # ข่าว                        (ข้อ ๒๒)
    CERTIFICATE = "certificate"          # หนังสือรับรอง                (ข้อ ๒๔)
    MINUTES = "minutes"                  # รายงานการประชุม              (ข้อ ๒๕)


DOC_TYPE_TH = {
    DocType.MEMO: "บันทึกข้อความ",
    DocType.EXTERNAL_LETTER: "หนังสือภายนอก",
    DocType.STAMP_LETTER: "หนังสือประทับตรา",
    DocType.ORDER: "คำสั่ง",
    DocType.REGULATION: "ระเบียบ",
    DocType.BYLAW: "ข้อบังคับ",
    DocType.ANNOUNCEMENT: "ประกาศ",
    DocType.STATEMENT: "แถลงการณ์",
    DocType.NEWS: "ข่าว",
    DocType.CERTIFICATE: "หนังสือรับรอง",
    DocType.MINUTES: "รายงานการประชุม",
}

Speed = Literal["ด่วนที่สุด", "ด่วนมาก", "ด่วน"]          # ข้อ ๒๘
Secrecy = Literal["ลับที่สุด", "ลับมาก", "ลับ"]


class Signer(BaseModel):
    """ข้อ ๑๑.๑๐–๑๑.๑๑: ลงลายมือชื่อ + พิมพ์ชื่อเต็มในวงเล็บใต้ลายมือชื่อ + ตำแหน่ง"""
    name: str = Field("[ระบุชื่อผู้ลงนาม]", description="ชื่อเต็ม ไม่ต้องใส่วงเล็บ ไม่ต้องใส่คำนำหน้าก็ได้")
    position: list[str] = Field(default_factory=lambda: ["[ระบุตำแหน่ง]"],
                                description="ตำแหน่ง แยกบรรทัด")


class Body(BaseModel):
    """ข้อความ: ภาคเหตุ → ภาคความประสงค์ → ภาคสรุป  (หลายประเด็นให้แยกเป็นข้อ)"""
    cause: list[str] = Field(..., description="ภาคเหตุ ขึ้นต้น 'ด้วย'/'ตาม'/'เนื่องด้วย'")
    purpose: list[str] = Field(..., description="ภาคความประสงค์")
    conclusion: str = Field(..., description="ภาคสรุป เช่น 'จึงเรียนมาเพื่อโปรดพิจารณา'")

    def paragraphs(self) -> list[str]:
        return [*self.cause, *self.purpose, self.conclusion]


class _Classified(BaseModel):
    speed: Optional[Speed] = Field(None, description="ชั้นความเร็ว (ข้อ ๒๘)")
    secrecy: Optional[Secrecy] = Field(None, description="ชั้นความลับ ตามระเบียบว่าด้วยการรักษาความลับของทางราชการ")


# ------------------------------------------------------------------- หนังสือโต้ตอบ
class ExternalLetterDoc(_Classified):
    """ข้อ ๑๑ หนังสือภายนอก — ใช้กระดาษตราครุฑ"""
    doc_type: Literal[DocType.EXTERNAL_LETTER] = DocType.EXTERNAL_LETTER
    doc_no: str = Field(..., description="๑๑.๑ ที่: รหัสตัวพยัญชนะ+เลขประจำเจ้าของเรื่อง/เลขทะเบียนหนังสือส่ง เช่น 'มท [ระบุเลขหน่วยงาน]/[ระบุ]'")
    agency: list[str] = Field(..., description="๑๑.๒ ส่วนราชการเจ้าของหนังสือ + ที่ตั้ง แยกบรรทัด")
    date: str = Field(..., description="๑๑.๓ วัน เดือน ปี: ตัวเลขวันที่ ชื่อเต็มของเดือน ตัวเลขปีพุทธศักราช")
    subject: str = Field(..., description="๑๑.๔ เรื่อง: ย่อที่สุด")
    salutation: str = Field("เรียน", description="๑๑.๕ คำขึ้นต้นตามฐานะผู้รับ (ภาคผนวก ๒)")
    to: str = Field(..., description="ตำแหน่ง/ชื่อผู้รับ ไม่ต้องมีคำขึ้นต้น")
    references: list[str] = Field(default_factory=list, description="๑๑.๖ อ้างถึง: หนังสือที่ติดต่อกันมาครั้งหลังสุด")
    attachments: list[str] = Field(default_factory=list, description="๑๑.๗ สิ่งที่ส่งมาด้วย")
    body: Body                                                      # ๑๑.๘
    closing: str = Field("ขอแสดงความนับถือ", description="๑๑.๙ คำลงท้าย (ภาคผนวก ๒)")
    signer: Signer = Signer()                                        # ๑๑.๑๐–๑๑.๑๑
    owner_unit: str = Field("[ระบุส่วนราชการเจ้าของเรื่อง]", description="๑๑.๑๒ ส่วนราชการเจ้าของเรื่อง")
    phone: str = Field("[ระบุ]", description="๑๑.๑๓ โทร.")
    fax: Optional[str] = None
    email: Optional[str] = Field(None, description="ไปรษณีย์อิเล็กทรอนิกส์ (ระบบสารบรรณอิเล็กทรอนิกส์ ฉบับที่ ๔)")
    copies_to: list[str] = Field(default_factory=list, description="๑๑.๑๔ สำเนาส่ง (ถ้ามี)")


class MemoSection(BaseModel):
    """หัวข้อบันทึกเสนอเรื่อง (คู่มือ กปภ. แบบที่ ๒/๒): เรื่องเดิม / ข้อเท็จจริง / ข้อกฎหมาย / ข้อพิจารณา / ข้อเสนอ"""
    heading: str
    paragraphs: list[str]


MEMO_SECTION_HEADINGS = ["เรื่องเดิม", "ข้อเท็จจริง", "ข้อกฎหมาย", "ข้อพิจารณา", "ข้อเสนอ"]


class MemoDoc(_Classified):
    """ข้อ ๑๒ หนังสือภายใน — ใช้กระดาษบันทึกข้อความ (อ้างถึง/สิ่งที่ส่งมาด้วยให้เขียนในข้อความ)"""
    doc_type: Literal[DocType.MEMO] = DocType.MEMO
    department: str = Field(..., description="๑๒.๑ ส่วนราชการ: เจ้าของเรื่อง + โทร.")
    doc_no: str = Field(..., description="๑๒.๒ ที่")
    date: str = Field(..., description="๑๒.๓ วันที่")
    subject: str = Field(..., description="๑๒.๔ เรื่อง")
    salutation: str = "เรียน"                                         # ๑๒.๕
    to: str
    body: Optional[Body] = None                                      # ๑๒.๖ (แบบ ๒/๑)
    sections: list[MemoSection] = Field(default_factory=list,
                                        description="แบบ ๒/๒ ของ กปภ.: ใช้แทน body เมื่อเสนอเรื่องเพื่อพิจารณา")
    signer: Signer = Signer()                                        # ๑๒.๗

    @model_validator(mode="after")
    def _need_body(self):
        if self.body is None and not self.sections:
            raise ValueError("ต้องมี body (แบบ ๒/๑) หรือ sections (แบบ ๒/๒)")
        return self


class StampLetterDoc(_Classified):
    """ข้อ ๑๓–๑๔ หนังสือประทับตรา — ใช้แทนการลงชื่อของหัวหน้าส่วนราชการระดับกรมขึ้นไป
    เฉพาะเรื่องไม่สำคัญ (ขอรายละเอียด ส่งสำเนา ตอบรับทราบ เตือนเรื่องที่ค้าง ฯลฯ)
    หัวหน้าส่วนราชการระดับกองหรือผู้ได้รับมอบหมาย ลงชื่อย่อกำกับตรา; ตราประทับด้วยหมึกแดง"""
    doc_type: Literal[DocType.STAMP_LETTER] = DocType.STAMP_LETTER
    doc_no: str = Field(..., description="๑๔.๑ ที่")
    to: str = Field(..., description="๑๔.๒ ถึง: ส่วนราชการ/หน่วยงาน/บุคคล")
    paragraphs: list[str] = Field(..., description="๑๔.๓ ข้อความ")
    issuer: str = Field(..., description="๑๔.๔ ส่วนราชการที่ส่งหนังสือออก")
    date: str = Field(..., description="๑๔.๖ วัน เดือน ปี")
    owner_unit: str = Field("[ระบุส่วนราชการเจ้าของเรื่อง]", description="๑๔.๗")
    phone: str = Field("[ระบุ]", description="๑๔.๘ โทร. หรือที่ตั้ง")
    email: Optional[str] = None


# ------------------------------------------------------------------- หนังสือสั่งการ
class OrderDoc(BaseModel):
    """ข้อ ๑๖ คำสั่ง — ใช้กระดาษตราครุฑ"""
    doc_type: Literal[DocType.ORDER] = DocType.ORDER
    issuer: str = Field(..., description="๑๖.๑ ส่วนราชการหรือตำแหน่งที่ออกคำสั่ง")
    doc_no: str = Field(..., description="๑๖.๒ ที่: เลขที่ (เริ่ม ๑ ทุกปีปฏิทิน)/ปีพุทธศักราช เช่น '๑๒๓/๒๕๖๙'")
    subject: str = Field(..., description="๑๖.๓ เรื่อง")
    paragraphs: list[str] = Field(..., description="๑๖.๔ ข้อความ: เหตุ + อำนาจ (ถ้ามี) + สิ่งที่สั่ง")
    effective: str = Field("ทั้งนี้ ตั้งแต่บัดนี้เป็นต้นไป", description="๑๖.๔ วันใช้บังคับ")
    date: str = Field(..., description="๑๖.๕ สั่ง ณ วันที่: '๒๑ ตุลาคม พ.ศ. ๒๕๖๙'")
    signer: Signer = Signer()                                        # ๑๖.๖–๑๖.๗


class Article(BaseModel):
    text: str = Field(..., description="ข้อความของข้อ ไม่ต้องพิมพ์ 'ข้อ n' ระบบใส่ให้")
    chapter: Optional[str] = Field(None, description="ชื่อหมวด ถ้าข้อนี้เริ่มหมวดใหม่ เช่น 'หมวด ๑ บททั่วไป'")


class RegulationDoc(BaseModel):
    """ข้อ ๑๗ ระเบียบ / ข้อ ๑๘ ข้อบังคับ — ใช้กระดาษตราครุฑ
    ข้อ ๑ ชื่อ, ข้อ ๒ วันใช้บังคับ, ข้อสุดท้าย ผู้รักษาการ"""
    doc_type: Literal[DocType.REGULATION, DocType.BYLAW] = DocType.REGULATION
    issuer: str = Field(..., description="๑๗.๑ ชื่อส่วนราชการที่ออก")
    title: str = Field(..., description="๑๗.๒ ว่าด้วย ... (ไม่ต้องพิมพ์คำว่า 'ว่าด้วย')")
    edition: Optional[str] = Field(None, description="๑๗.๓ ฉบับที่ (ฉบับแรกไม่ต้องระบุ)")
    year: str = Field(..., description="๑๗.๔ พ.ศ.")
    preamble: str = Field(..., description="๑๗.๕ เหตุผลโดยย่อ + อำนาจ เช่น 'โดยที่เป็นการสมควร... อาศัยอำนาจตาม... จึงวางระเบียบไว้ ดังต่อไปนี้'")
    articles: list[Article] = Field(..., description="๑๗.๖ ข้อ ๑ ชื่อ / ข้อ ๒ วันใช้บังคับ / ... / ข้อสุดท้าย ผู้รักษาการ")
    date: str = Field(..., description="๑๗.๗ ประกาศ ณ วันที่")
    signer: Signer = Signer()


class AnnouncementDoc(BaseModel):
    """ข้อ ๒๐ ประกาศ (หรือ 'แจ้งความ' เมื่อกฎหมายกำหนด) — ใช้กระดาษตราครุฑ"""
    doc_type: Literal[DocType.ANNOUNCEMENT] = DocType.ANNOUNCEMENT
    word: Literal["ประกาศ", "แจ้งความ"] = "ประกาศ"
    issuer: str = Field(..., description="๒๐.๑ ส่วนราชการที่ออกประกาศ")
    subject: str = Field(..., description="๒๐.๒ เรื่อง")
    paragraphs: list[str] = Field(..., description="๒๐.๓ ข้อความ: เหตุผล + สิ่งที่ประกาศ")
    date: str = Field(..., description="๒๐.๔ ประกาศ ณ วันที่")
    signer: Signer = Signer()


# ------------------------------------------------------------------- หนังสือประชาสัมพันธ์
class StatementDoc(BaseModel):
    """ข้อ ๒๑ แถลงการณ์ / ข้อ ๒๒ ข่าว — ใช้กระดาษตราครุฑ ไม่มีลายมือชื่อ"""
    doc_type: Literal[DocType.STATEMENT, DocType.NEWS] = DocType.STATEMENT
    issuer: str = Field(..., description="๒๑.๑ ส่วนราชการที่ออก")
    subject: str = Field(..., description="๒๑.๒ เรื่อง")
    number: Optional[str] = Field(None, description="๒๑.๓ ฉบับที่ (ถ้ามีหลายฉบับในเรื่องเดียวกัน)")
    paragraphs: list[str] = Field(..., description="๒๑.๔ ข้อความ")
    date: str = Field(..., description="๒๑.๖ วัน เดือน ปี")


# ------------------------------------------------------------------- หนังสือที่เจ้าหน้าที่ทำขึ้น
class CertificateDoc(BaseModel):
    """ข้อ ๒๔ หนังสือรับรอง — ใช้กระดาษตราครุฑ"""
    doc_type: Literal[DocType.CERTIFICATE] = DocType.CERTIFICATE
    doc_no: str = Field(..., description="๒๔.๑ เลขที่ เช่น '[ระบุ]/๒๕๖๙'")
    agency: list[str] = Field(..., description="๒๔.๒ ส่วนราชการเจ้าของหนังสือ (+ ที่ตั้ง)")
    body: list[str] = Field(..., description="๒๔.๓ ข้อความ ขึ้นต้นว่า 'หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า' "
                                             "+ ชื่อเต็ม ตำแหน่ง สังกัด + สิ่งที่รับรอง")
    date: str = Field(..., description="๒๔.๔ ให้ไว้ ณ วันที่")
    signer: Signer = Signer()                                        # ๒๔.๕–๒๔.๖
    photo_holder: Optional[str] = Field(None, description="๒๔.๗ ชื่อผู้ได้รับการรับรอง (เรื่องสำคัญ ติดรูป ๔x๖ ซม.)")


class AgendaItem(BaseModel):
    title: str
    discussion: list[str] = Field(default_factory=list)
    resolution: str = "[ระบุมติที่ประชุม]"


class MinutesDoc(BaseModel):
    """ข้อ ๒๕ รายงานการประชุม"""
    doc_type: Literal[DocType.MINUTES] = DocType.MINUTES
    title: str = Field(..., description="๒๕.๑ รายงานการประชุม + ชื่อคณะที่ประชุม/ชื่อการประชุม")
    session: str = Field("ครั้งที่ [ระบุ]", description="๒๕.๒")
    date: str = Field("[ระบุวันที่ประชุม]", description="๒๕.๓ เมื่อ")
    place: str = Field("[ระบุสถานที่]", description="๒๕.๔ ณ")
    attendees: list[str] = Field(default_factory=lambda: ["[ระบุรายชื่อผู้มาประชุม]"],
                                 description="๒๕.๕ ผู้มาประชุม (ผู้แทน: ระบุว่ามาแทนผู้ใด)")
    absentees: list[str] = Field(default_factory=list, description="๒๕.๖ ผู้ไม่มาประชุม (พร้อมเหตุผล ถ้ามี)")
    others: list[str] = Field(default_factory=list, description="๒๕.๗ ผู้เข้าร่วมประชุม")
    start_time: str = Field("[ระบุ]", description="๒๕.๘")
    agenda: list[AgendaItem]                                          # ๒๕.๙
    end_time: str = Field("[ระบุ]", description="๒๕.๑๐")
    recorder: Signer = Signer(name="[ระบุผู้จดรายงานการประชุม]", position=["ผู้จดรายงานการประชุม"])  # ๒๕.๑๑


AnyDoc = Union[MemoDoc, ExternalLetterDoc, StampLetterDoc, OrderDoc, RegulationDoc,
               AnnouncementDoc, StatementDoc, CertificateDoc, MinutesDoc]

MODEL_BY_TYPE: dict[DocType, type[BaseModel]] = {
    DocType.MEMO: MemoDoc,
    DocType.EXTERNAL_LETTER: ExternalLetterDoc,
    DocType.STAMP_LETTER: StampLetterDoc,
    DocType.ORDER: OrderDoc,
    DocType.REGULATION: RegulationDoc,
    DocType.BYLAW: RegulationDoc,
    DocType.ANNOUNCEMENT: AnnouncementDoc,
    DocType.STATEMENT: StatementDoc,
    DocType.NEWS: StatementDoc,
    DocType.CERTIFICATE: CertificateDoc,
    DocType.MINUTES: MinutesDoc,
}

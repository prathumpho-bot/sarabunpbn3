"""Client สำหรับ LLM ที่มี API แบบ OpenAI-compatible (/v1/chat/completions)

ใช้ได้ทั้ง
  - เซิร์ฟเวอร์ภายใน กปภ. (vLLM / Ollama / llama.cpp)  → structured output ตรง schema (json_schema)
  - ThaiLLM API (thaillm.or.th) — ดู sarabun/llm/thaillm.py   → ใส่ schema ใน prompt + ตรวจ/ซ่อม JSON

ตั้งค่าผ่าน env (ดู llm_from_env):
  SARABUN_LLM_PROVIDER  onprem (ค่าเริ่มต้น) | thaillm | thaillm+onprem (ThaiLLM ก่อน ล้มแล้วใช้เซิร์ฟเวอร์ภายใน)
                        | onprem+thaillm
  SARABUN_LLM_URL / SARABUN_LLM_MODEL / SARABUN_LLM_KEY      เซิร์ฟเวอร์ภายใน
  THAILLM_API_KEY / THAILLM_BASE_URL / THAILLM_MODEL         ThaiLLM
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import deque
from typing import Any, Literal, Optional, Protocol

import httpx

StructuredMode = Literal["json_schema", "json_object", "prompt"]
_THINK_RE = re.compile(r"<think>.*?</think>", re.S)


class LLM(Protocol):
    def chat_json(self, system: str, user: str, schema: Optional[dict] = None) -> dict: ...


class LLMError(RuntimeError):
    pass


class RateLimiter:
    """จำกัดอัตราเรียกฝั่ง client (เช่น ThaiLLM: ๕ ครั้ง/วินาที, ๒๐๐ ครั้ง/นาที)"""

    def __init__(self, per_second: Optional[float] = None, per_minute: Optional[int] = None,
                 clock=time.monotonic, sleep=time.sleep):
        self.per_second, self.per_minute = per_second, per_minute
        self.clock, self.sleep = clock, sleep
        self.hist: deque[float] = deque()
        self.last = -1e9
        self.lock = threading.Lock()

    def wait(self):
        with self.lock:
            now = self.clock()
            if self.per_second:
                gap = 1.0 / self.per_second - (now - self.last)
                if gap > 0:
                    self.sleep(gap)
                    now = self.clock()
            if self.per_minute:
                while self.hist and now - self.hist[0] >= 60:
                    self.hist.popleft()
                if len(self.hist) >= self.per_minute:
                    self.sleep(60 - (now - self.hist[0]))
                    now = self.clock()
                    self.hist.popleft()
                self.hist.append(now)
            self.last = now


class OpenAICompatLLM:
    """structured:
         json_schema  ส่ง response_format แบบ json_schema (vLLM/llama.cpp/Ollama รุ่นใหม่)
         json_object  ส่ง response_format แบบ json_object + schema ใน prompt
         prompt       ไม่ส่ง response_format เลย — ใส่ schema ใน system prompt แล้วแยก JSON จากคำตอบ
       หาก endpoint ตอบ 400/422 เพราะไม่รองรับ response_format จะลดระดับเป็น prompt อัตโนมัติ"""

    name = "onprem"

    def __init__(self, base_url: Optional[str] = None, model: Optional[str] = None,
                 api_key: Optional[str] = None, timeout: float = 180, *,
                 structured: StructuredMode = "json_schema", temperature: float = 0.2,
                 max_tokens: Optional[int] = None, strip_think: bool = True, retries: int = 3,
                 rate_limiter: Optional[RateLimiter] = None, external: bool = False,
                 transport: Optional[httpx.BaseTransport] = None, sleep=time.sleep):
        self.base_url = (base_url or os.getenv("SARABUN_LLM_URL", "http://localhost:8000/v1")).rstrip("/")
        self.model = model or os.getenv("SARABUN_LLM_MODEL", "scb10x/typhoon2.1-gemma3-12b")
        self.api_key = api_key or os.getenv("SARABUN_LLM_KEY", "none")
        self.structured = structured
        self.temperature, self.max_tokens = temperature, max_tokens
        self.strip_think, self.retries = strip_think, retries
        self.rate_limiter = rate_limiter
        self.external = external              # True = ข้อมูลออกนอกเครือข่าย กปภ.
        self.sleep = sleep
        self.http = httpx.Client(timeout=timeout, transport=transport)

    # ------------------------------------------------------------------ public
    def info(self) -> dict:
        return {"provider": self.name, "base_url": self.base_url, "model": self.model,
                "structured": self.structured, "external": self.external}

    def list_models(self) -> list[str]:
        r = self.http.get(f"{self.base_url}/models", headers=self._headers())
        r.raise_for_status()
        return [m.get("id") for m in r.json().get("data", [])]

    def chat_json(self, system: str, user: str, schema: Optional[dict] = None) -> dict:
        content = self.chat(system, user, schema=schema, want_json=True)
        try:
            return parse_json(content)
        except ValueError:
            # ซ่อม: ขอให้ตอบใหม่เป็น JSON อย่างเดียว (โมเดลเล็กบางครั้งตอบข้อความนำหน้า/ปิดวงเล็บไม่ครบ)
            fix = (f"{user}\n\nคำตอบก่อนหน้าไม่ใช่ JSON ที่ถูกต้อง:\n{content[:1500]}\n\n"
                   "ตอบใหม่เป็น JSON object เพียงอย่างเดียว ไม่มีข้อความอื่น")
            return parse_json(self.chat(system, fix, schema=schema, want_json=True))

    def chat(self, system: str, user: str, *, schema: Optional[dict] = None, want_json: bool = False) -> str:
        mode = self.structured
        while True:
            body = self._body(system, user, schema, want_json, mode)
            try:
                return self._post(body)
            except _Unsupported:
                if mode == "prompt":
                    raise LLMError("endpoint ปฏิเสธคำขอ") from None
                mode = "prompt"
                self.structured = "prompt"     # จำไว้ ไม่ต้องลองซ้ำทุกครั้ง

    # ----------------------------------------------------------------- helpers
    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}

    def _body(self, system, user, schema, want_json, mode) -> dict:
        if want_json and mode != "json_schema":
            system = system + "\n\n" + json_instruction(schema)
        body: dict[str, Any] = {
            "model": self.model, "temperature": self.temperature,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        }
        if self.max_tokens:
            body["max_tokens"] = self.max_tokens
        if want_json and mode == "json_schema" and schema:
            body["response_format"] = {"type": "json_schema",
                                       "json_schema": {"name": "doc", "schema": schema, "strict": True}}
        elif want_json and mode in ("json_schema", "json_object"):
            body["response_format"] = {"type": "json_object"}
        return body

    def _post(self, body: dict) -> str:
        delay = 1.0
        for attempt in range(self.retries + 1):
            if self.rate_limiter:
                self.rate_limiter.wait()
            try:
                r = self.http.post(f"{self.base_url}/chat/completions", json=body, headers=self._headers())
            except httpx.ProxyError as e:
                raise LLMError(f"proxy/firewall ปฏิเสธการเชื่อมต่อไป {self.base_url} ({e}) — "
                               "ตรวจว่าเครื่องนี้ออกอินเทอร์เน็ตไปโดเมนนี้ได้") from e
            except httpx.TransportError as e:
                if attempt == self.retries:
                    raise LLMError(f"เชื่อมต่อ {self.base_url} ไม่ได้: {e}") from e
                self.sleep(delay)
                delay *= 2
                continue
            if r.status_code in (400, 422) and "response_format" in body:
                raise _Unsupported()
            if r.status_code in (401, 403):
                raise LLMError(f"{self.name}: API key ไม่ถูกต้องหรือไม่มีสิทธิ์ ({r.status_code})")
            if r.status_code == 429 or r.status_code >= 500:
                if attempt == self.retries:
                    raise LLMError(f"{self.name}: {r.status_code} หลังลองซ้ำ {self.retries} ครั้ง")
                ra = r.headers.get("retry-after")
                self.sleep(float(ra) if ra and ra.replace(".", "", 1).isdigit() else delay)
                delay *= 2
                continue
            if r.status_code >= 400:
                raise LLMError(f"{self.name}: {r.status_code} {r.text[:300]}")
            content = r.json()["choices"][0]["message"]["content"] or ""
            return _THINK_RE.sub("", content).strip() if self.strip_think else content
        raise LLMError("unreachable")  # pragma: no cover


class _Unsupported(Exception):
    pass


def json_instruction(schema: Optional[dict]) -> str:
    """คำสั่งให้ตอบเป็น JSON (ใช้กับ endpoint ที่ไม่มี structured output เช่น ThaiLLM)"""
    head = "ตอบเป็น JSON object เพียงอย่างเดียว ห้ามมีข้อความอื่น ห้ามใส่ ``` และห้ามใส่คำอธิบาย"
    if not schema:
        return head
    return f"{head}\nโครงสร้าง JSON ต้องตรงกับ JSON Schema นี้ (ใช้ชื่อ field ตามนี้ทุกตัว):\n" + \
        json.dumps(schema, ensure_ascii=False, separators=(",", ":"))


def parse_json(text: str) -> dict:
    """แยก JSON object ตัวแรกจากคำตอบ (รองรับ ```json ... ```, ข้อความนำหน้า, <think>)"""
    text = _THINK_RE.sub("", text).strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    start = text.find("{")
    if start < 0:
        raise ValueError("ไม่พบ JSON")
    depth, in_str, esc = 0, False, False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError as e:
                    raise ValueError(str(e)) from e
    raise ValueError("JSON ไม่สมบูรณ์")


_parse_json = parse_json   # ชื่อเดิม


class FallbackLLM:
    """ลองตัวแรกก่อน ถ้าล้ม (เครือข่าย/โควตา/JSON เสีย) ใช้ตัวถัดไป — เช่น ThaiLLM → เซิร์ฟเวอร์ภายใน"""

    name = "fallback"

    def __init__(self, *llms):
        self.llms = list(llms)
        self.last_used: Optional[Any] = None

    @property
    def external(self) -> bool:
        return any(getattr(x, "external", False) for x in self.llms)

    def internal_only(self):
        """LLM ที่ไม่ส่งข้อมูลออกนอก กปภ. (ใช้กับหนังสือชั้นความลับ) — None ถ้าไม่มี"""
        inner = [x for x in self.llms if not getattr(x, "external", False)]
        return None if not inner else inner[0] if len(inner) == 1 else FallbackLLM(*inner)

    def info(self) -> dict:
        return {"provider": "+".join(getattr(x, "name", "?") for x in self.llms), "external": self.external,
                "chain": [x.info() if hasattr(x, "info") else {} for x in self.llms]}

    def chat_json(self, system: str, user: str, schema: Optional[dict] = None) -> dict:
        err: Optional[Exception] = None
        for llm in self.llms:
            try:
                out = llm.chat_json(system, user, schema)
                self.last_used = llm
                return out
            except (LLMError, ValueError, httpx.HTTPError) as e:
                err = e
        raise LLMError(f"ทุก LLM ล้มเหลว: {err}")


class MockLLM:
    """ใช้ทดสอบโดยไม่ต้องมี GPU: คืนค่าที่กำหนดไว้ล่วงหน้า"""

    name = "mock"
    external = False

    def __init__(self, responses: list[dict]):
        self.responses = list(responses)
        self.calls: list[tuple[str, str]] = []

    def info(self) -> dict:
        return {"provider": "mock", "external": False}

    def chat_json(self, system: str, user: str, schema: Optional[dict] = None) -> dict:
        self.calls.append((system, user))
        return self.responses.pop(0)


def llm_from_env(provider: Optional[str] = None):
    """สร้าง LLM ตาม SARABUN_LLM_PROVIDER"""
    from .privacy import PrivacyGuardLLM
    from .thaillm import ThaiLLM

    provider = (provider or os.getenv("SARABUN_LLM_PROVIDER", "onprem")).lower()
    built = []
    for p in provider.split("+"):
        if p == "thaillm":
            built.append(PrivacyGuardLLM(ThaiLLM()))     # ข้อมูลออกนอก กปภ. → ปิดบังข้อมูลส่วนบุคคลก่อนส่ง
        elif p in ("onprem", "local", "vllm"):
            built.append(OpenAICompatLLM())
        else:
            raise ValueError(f"ไม่รู้จัก provider '{p}' (onprem | thaillm | thaillm+onprem)")
    return built[0] if len(built) == 1 else FallbackLLM(*built)

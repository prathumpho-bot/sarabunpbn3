"""ThaiLLM API — โมเดลภาษาไทยของโครงการ ThaiLLM (https://thaillm.or.th — API/Playground ให้บริการโดย BDI)

ตามหน้า "How to Use" ของ ThaiLLM (ผู้ใช้ส่งมา ต.ค. ๒๕๖๙):
  - endpoint เดียวแบบ OpenAI-compatible:  POST https://thaillm.or.th/api/v1/chat/completions
    (เอกสารแสดง http:// — ระบบใช้ https:// เพราะ API key อยู่ใน header; ตรวจแล้วว่า https ตอบ /api/v1/models ได้)
  - auth: "Authorization: Bearer <key>" (มาตรฐาน OpenAI, ค่าเริ่มต้น) หรือ "apikey: <key>" (แบบเดิม)
  - เลือกโมเดลใน body ด้วยชื่อเต็ม (ไม่สนตัวพิมพ์เล็กใหญ่) หรือชื่อย่อ openthaigpt / pathumma / typhoon / thalle (kbtg)
  - ขอ API key ที่ ThaiLLM Playground (https://playground.thaillm.or.th)
  - Rate limits ตามเอกสาร: ๕ ครั้ง/วินาที และ ๒๐๐ ครั้ง/นาที — ระบบจำกัดฝั่ง client ไว้ไม่เกินนี้
    (THAILLM_RPS / THAILLM_RPM ปรับให้ต่ำลงได้ แต่ไม่เกินค่าทางการ)
  - เอกสารไม่ได้ระบุ response_format → ใช้โหมด prompt (ใส่ schema ใน prompt) แล้วตรวจ JSON ด้วย pydantic

ข้อควรระวัง (ข้อกำหนดการใช้ Playground/API):
  - ข้อมูลที่ส่งเข้าไป ผู้ให้บริการนำไปใช้พัฒนา/ฝึกโมเดลได้ และห้ามใส่ข้อมูลส่วนบุคคล/ข้อมูลอ่อนไหว
  - ใช้ผลลัพธ์เชิงพาณิชย์ต้องได้รับความยินยอมเป็นลายลักษณ์อักษร / ไม่มี SLA
  → ระบบนี้ปิดบังข้อมูลส่วนบุคคลก่อนส่ง (privacy.py) และไม่ส่งหนังสือที่มีชั้นความลับ (service.py)
"""
from __future__ import annotations

import os
from typing import Optional

from .client import OpenAICompatLLM, RateLimiter

RATE_LIMIT_RPS, RATE_LIMIT_RPM = 5, 200                # ตามเอกสาร ThaiLLM
THAILLM_BASE_URL = "https://thaillm.or.th/api/v1"     # ตามเอกสาร (ใช้ https) — api.thaillm.or.th/v1 ก็ตอบเช่นกัน

# ๔ โมเดลตามเอกสาร How to Use (ชื่อเต็ม → ชื่อย่อที่ API รับ)
THAILLM_MODELS = {
    "Typhoon-S-ThaiLLM-8B-Instruct": "typhoon — SCB 10X (ค่าเริ่มต้น)",
    "OpenThaiGPT-ThaiLLM-8B-Instruct-v7.2": "openthaigpt — AIEAT",
    "Pathumma-ThaiLLM-qwen3-8b-think-3.0.0": "pathumma — NECTEC มีขั้นคิด <think> (ระบบตัดออกให้)",
    "THaLLE-0.2-ThaiLLM-8B-fa": "thalle / kbtg — KBTG",
}
SHORTHAND = {"typhoon": "Typhoon-S-ThaiLLM-8B-Instruct", "openthaigpt": "OpenThaiGPT-ThaiLLM-8B-Instruct-v7.2",
             "pathumma": "Pathumma-ThaiLLM-qwen3-8b-think-3.0.0", "thalle": "THaLLE-0.2-ThaiLLM-8B-fa",
             "kbtg": "THaLLE-0.2-ThaiLLM-8B-fa"}
# /api/v1/models ตอบ qwen3.5-9b และ qwen3.6-35b-a3b ด้วย แต่ไม่อยู่ในเอกสาร — ใช้ได้โดยระบุชื่อเต็ม ไม่รับประกัน


def resolve_model(name: str) -> str:
    """ชื่อย่อ/ชื่อเต็มแบบไม่สนตัวพิมพ์ → ชื่อเต็ม (ชื่ออื่นส่งไปตามเดิม)"""
    key = name.strip().lower()
    if key in SHORTHAND:
        return SHORTHAND[key]
    return next((m for m in THAILLM_MODELS if m.lower() == key), name.strip())


DEFAULT_MODEL = "Typhoon-S-ThaiLLM-8B-Instruct"


class ThaiLLM(OpenAICompatLLM):
    name = "thaillm"

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None,
                 base_url: Optional[str] = None, auth_header: Optional[str] = None, **kw):
        key = api_key or os.getenv("THAILLM_API_KEY")
        if not key:
            raise ValueError("ต้องตั้ง THAILLM_API_KEY (ขอได้ที่ https://playground.thaillm.or.th)")
        rps = min(float(os.getenv("THAILLM_RPS", RATE_LIMIT_RPS)), RATE_LIMIT_RPS)
        rpm = min(int(os.getenv("THAILLM_RPM", RATE_LIMIT_RPM)), RATE_LIMIT_RPM)
        kw.setdefault("structured", os.getenv("THAILLM_STRUCTURED", "prompt"))
        kw.setdefault("max_tokens", int(os.getenv("THAILLM_MAX_TOKENS", "4096")))
        kw.setdefault("timeout", float(os.getenv("THAILLM_TIMEOUT", "120")))
        kw.setdefault("rate_limiter", RateLimiter(per_second=rps, per_minute=rpm))
        url = (base_url or os.getenv("THAILLM_BASE_URL", THAILLM_BASE_URL)).strip()
        if url.startswith("http://") and os.getenv("THAILLM_ALLOW_HTTP") != "1":
            url = "https://" + url[len("http://"):]       # ไม่ส่ง API key/เนื้อหาหนังสือแบบไม่เข้ารหัส
        self.auth_header = (auth_header or os.getenv("THAILLM_AUTH_HEADER", "bearer")).lower()
        if self.auth_header not in ("bearer", "apikey"):
            raise ValueError("THAILLM_AUTH_HEADER ต้องเป็น bearer หรือ apikey")
        super().__init__(base_url=url, model=resolve_model(model or os.getenv("THAILLM_MODEL", DEFAULT_MODEL)),
                         api_key=key, external=True, **kw)

    def _headers(self) -> dict:
        if self.auth_header == "apikey":                   # แบบเดิมของ ThaiLLM
            return {"apikey": self.api_key, "Content-Type": "application/json"}
        return super()._headers()

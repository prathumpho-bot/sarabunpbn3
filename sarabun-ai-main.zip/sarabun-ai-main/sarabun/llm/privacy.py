"""ปิดบังข้อมูลส่วนบุคคลก่อนส่งให้ LLM ภายนอก (เช่น ThaiLLM) แล้วคืนค่าเดิมในคำตอบ

ข้อกำหนด ThaiLLM: ห้ามส่งข้อมูลส่วนบุคคล/ข้อมูลอ่อนไหว และผู้ให้บริการนำข้อมูลไปพัฒนาโมเดลได้
→ เลขบัตรประชาชน, เลขโทรศัพท์, อีเมล, เลขบัญชีธนาคาร ถูกแทนด้วยรหัส ⟦P1⟧ ⟦P2⟧ … ก่อนส่ง
   แล้วแทนกลับในผลลัพธ์ (ข้อมูลจริงไม่ออกนอกเครือข่าย กปภ.)
ชื่อบุคคลยังไม่ถูกปิดบัง (ต้องใช้ NER) — ผู้ใช้ควรใส่ชื่อจริงหลังได้ร่างแล้ว หรือใช้ [ระบุชื่อ]
"""
from __future__ import annotations

import re
from typing import Any, Optional

_D = r"[0-9๐-๙]"
PATTERNS = [
    ("email", re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")),
    ("citizen_id", re.compile(rf"(?<!{_D}){_D}[- ]?{_D}{{4}}[- ]?{_D}{{5}}[- ]?{_D}{{2}}[- ]?{_D}(?!{_D})")),
    ("bank_account", re.compile(rf"(?<!{_D}){_D}{{3}}-{_D}-{_D}{{5}}-{_D}(?!{_D})")),
    ("phone", re.compile(rf"(?<!{_D})(?:\+66[- ]?|0|๐)(?:[- ]?{_D}){{8,9}}(?!{_D})")),
]
_ANY = re.compile("|".join(f"(?P<{n}>{rx.pattern})" for n, rx in PATTERNS))


class PIIMasker:
    def __init__(self):
        self.forward: dict[str, str] = {}
        self.back: dict[str, str] = {}

    def mask(self, text: str) -> str:
        return _ANY.sub(self._token, text)       # รหัสเรียงตามลำดับที่พบในข้อความ

    def _token(self, m: re.Match) -> str:
        v = m.group(0)
        if v not in self.forward:
            t = f"⟦P{len(self.forward) + 1}⟧"
            self.forward[v], self.back[t] = t, v
        return self.forward[v]

    def unmask(self, obj: Any) -> Any:
        if isinstance(obj, str):
            for t, v in self.back.items():
                obj = obj.replace(t, v)
            return obj
        if isinstance(obj, list):
            return [self.unmask(x) for x in obj]
        if isinstance(obj, dict):
            return {k: self.unmask(v) for k, v in obj.items()}
        return obj


class PrivacyGuardLLM:
    """ห่อ LLM ภายนอก: ปิดบังข้อมูลส่วนบุคคลขาไป คืนค่าขากลับ"""

    external = True

    def __init__(self, inner):
        self.inner = inner
        self.name = getattr(inner, "name", "external")
        self.last_masked: Optional[dict[str, str]] = None

    def info(self) -> dict:
        d = self.inner.info() if hasattr(self.inner, "info") else {}
        return {**d, "external": True, "pii_masking": True}

    def list_models(self):
        return self.inner.list_models()

    def chat_json(self, system: str, user: str, schema: Optional[dict] = None) -> dict:
        m = PIIMasker()
        out = self.inner.chat_json(m.mask(system), m.mask(user), schema)
        self.last_masked = dict(m.back)
        return m.unmask(out)

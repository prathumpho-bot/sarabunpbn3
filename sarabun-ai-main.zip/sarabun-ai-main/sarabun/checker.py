"""ตรวจหนังสือตามระเบียบงานสารบรรณ + แนวทางการพิมพ์ นร ๐๑๐๖/ว ๒๐๑๙ (rule-based, deterministic)

check_document(doc) — ตรวจโครงสร้าง/ถ้อยคำของร่าง (ก่อน render)  : ทุก rule อ้างข้อของระเบียบ
check_docx(path)    — ตรวจไฟล์ .docx ที่ผู้ใช้เขียนเอง           : ขอบ ฟอนต์ ขนาด ครุฑ ระยะ
ส่วนที่ต้องใช้วิจารณญาณ (ภาษาราชการ ความชัดเจน) ให้ LLM ตรวจเพิ่มในชั้น service
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

from . import salutations
from .schema import (AnnouncementDoc, AnyDoc, CertificateDoc, DocType, ExternalLetterDoc, MemoDoc,
                     MinutesDoc, OrderDoc, RegulationDoc, StampLetterDoc, StatementDoc)
from .style import DEFAULT_SPEC, NATIONAL_FONTS, LayoutSpec
from .thai_utils import THAI_MONTHS, find_placeholders, has_arabic_digits, to_arabic_digits

Level = Literal["error", "warning", "info"]


@dataclass
class Finding:
    level: Level
    rule: str
    message: str
    where: str = ""
    ref: str = ""          # ข้อของระเบียบ / แนวทางที่อ้าง

    def dict(self):
        return asdict(self)


_NUM = "[0-9๐-๙]"
DATE_RE = re.compile(rf"^\s*({_NUM}{{1,2}})\s+({'|'.join(THAI_MONTHS)})\s+(?:พ\.ศ\.\s*)?({_NUM}{{4}})\s*$")
YEAR_NO_RE = re.compile(rf"^.+/\s*{_NUM}{{4}}$")           # เลขที่/ปีพุทธศักราช
INFORMAL = {"ครับ": "ภาษาพูด", "ค่ะ": "ภาษาพูด", "นะคะ": "ภาษาพูด", "เยอะ": "ใช้ 'จำนวนมาก'",
            "ได้มั้ย": "ภาษาพูด", "อยากจะ": "ใช้ 'มีความประสงค์จะ'", "ช่วย": "ใช้ 'ขอความอนุเคราะห์'",
            "เลยขอ": "ภาษาพูด"}


def _texts(doc: AnyDoc) -> dict[str, str]:
    out: dict[str, str] = {}

    def walk(prefix, v):
        if isinstance(v, str):
            out[prefix] = v
        elif isinstance(v, list):
            for i, x in enumerate(v):
                walk(f"{prefix}[{i}]", x)
        elif isinstance(v, dict):
            for k, x in v.items():
                walk(f"{prefix}.{k}" if prefix else k, x)
    walk("", doc.model_dump(mode="json"))
    return out


def _check_date(f: list[Finding], value: str, where: str = "date", ref: str = "ข้อ ๑๑.๓"):
    if not value or find_placeholders(value):
        return
    m = DATE_RE.match(value)
    if not m:
        f.append(Finding("error", "DATE_FORMAT", "วันที่ต้องเป็น 'ตัวเลขวันที่ ชื่อเต็มของเดือน ตัวเลขปีพุทธศักราช' "
                         "เช่น ๓ ตุลาคม ๒๕๖๙", where, ref))
    elif int(to_arabic_digits(m.group(3))) < 2400:
        f.append(Finding("error", "DATE_BE", "ปีต้องเป็นพุทธศักราช", where, ref))


def check_document(doc: AnyDoc, spec: LayoutSpec = DEFAULT_SPEC) -> list[Finding]:
    f: list[Finding] = []
    texts = _texts(doc)

    for where, t in texts.items():
        for ph in find_placeholders(t):
            f.append(Finding("warning", "PLACEHOLDER", f"ยังไม่ได้กรอก {ph}", where))
        for w, why in INFORMAL.items():
            if re.search(rf"(?<![ก-๙]){w}(?![ก-๙])", t):
                f.append(Finding("warning", "INFORMAL_WORD", f"พบคำ '{w}' — {why}", where, "ภาษาหนังสือราชการ"))

    if not isinstance(doc, MinutesDoc):
        _check_date(f, getattr(doc, "date", ""))

    subj = getattr(doc, "subject", "") or ""
    if len(subj) > 120:
        f.append(Finding("warning", "SUBJECT_LONG", "เรื่องให้ลงเรื่องย่อที่เป็นใจความสั้นที่สุด", "subject", "ข้อ ๑๑.๔"))

    signer = getattr(doc, "signer", None)
    if signer and signer.name.strip().startswith("("):
        f.append(Finding("info", "SIGNER_PAREN", "ไม่ต้องใส่วงเล็บ ระบบพิมพ์ชื่อเต็มในวงเล็บให้", "signer.name", "ข้อ ๑๑.๑๐"))

    # ---- หนังสือโต้ตอบ: ที่ = รหัส/เลขทะเบียนส่ง (ข้อ ๑๑.๑, ๑๒.๒, ๑๔.๑)
    if isinstance(doc, (MemoDoc, ExternalLetterDoc, StampLetterDoc)) and "/" not in doc.doc_no:
        f.append(Finding("error", "DOC_NO", "ที่ ต้องเป็น 'รหัสตัวพยัญชนะและเลขประจำของเจ้าของเรื่อง/เลขทะเบียนหนังสือส่ง'",
                         "doc_no", "ข้อ ๑๑.๑"))

    body = getattr(doc, "body", None)
    if isinstance(doc, MemoDoc) and body is None:
        heads = [x.heading for x in doc.sections]
        if not any("ข้อเสนอ" in h for h in heads):
            f.append(Finding("warning", "MEMO_PROPOSAL", "บันทึกแบบ ๒/๒ ควรจบด้วยหัวข้อ 'ข้อเสนอ'", "sections",
                             "คู่มือ กปภ. แบบที่ ๒/๒"))
    elif isinstance(doc, (MemoDoc, ExternalLetterDoc)):
        if not body.cause:
            f.append(Finding("error", "BODY_CAUSE", "ไม่มีภาคเหตุ", "body.cause", "หลักการเขียนหนังสือราชการ"))
        if not body.purpose:
            f.append(Finding("error", "BODY_PURPOSE", "ไม่มีภาคความประสงค์", "body.purpose", "หลักการเขียนหนังสือราชการ"))
        if not body.conclusion.strip().startswith(("จึง", "ทั้งนี้", "อนึ่ง")):
            f.append(Finding("info", "BODY_CONCLUSION", "ภาคสรุปมักขึ้นต้น 'จึงเรียนมาเพื่อ...'", "body.conclusion"))
        if body.cause and not body.cause[0].startswith(("ด้วย", "ตาม", "เนื่องด้วย", "เนื่องจาก", "อนุสนธิ")):
            f.append(Finding("info", "BODY_OPENING", "ภาคเหตุมักขึ้นต้น 'ด้วย' / 'ตาม' / 'เนื่องด้วย'", "body.cause[0]"))

    if isinstance(doc, ExternalLetterDoc):
        if not salutations.pair_ok(doc.salutation, doc.closing):
            f.append(Finding("error", "SALUTATION_PAIR", f"คำขึ้นต้น '{doc.salutation}' ไม่คู่กับคำลงท้าย '{doc.closing}'",
                             "closing", "ข้อ ๑๑.๕, ๑๑.๙ / ภาคผนวก ๒"))
        exp_sal, _ = salutations.suggest(doc.to)
        if exp_sal != doc.salutation:
            f.append(Finding("warning", "SALUTATION_RANK", f"ผู้รับ '{doc.to}' ควรใช้คำขึ้นต้น '{exp_sal}'",
                             "salutation", "ภาคผนวก ๒"))
        if doc.references and len(doc.references) > 1:
            f.append(Finding("info", "REF_LATEST", "อ้างถึงให้อ้างหนังสือที่ติดต่อกันมาครั้งหลังสุดเพียงฉบับเดียว "
                             "เว้นแต่มีสาระที่ต้องพิจารณาต่อเนื่อง", "references", "ข้อ ๑๑.๖"))
        if not doc.owner_unit or not doc.phone:
            f.append(Finding("error", "OWNER_UNIT", "ต้องมีส่วนราชการเจ้าของเรื่องและโทร.", "owner_unit", "ข้อ ๑๑.๑๒–๑๑.๑๓"))

    if isinstance(doc, MemoDoc) and "โทร" not in doc.department:
        f.append(Finding("info", "MEMO_PHONE", "ส่วนราชการ ให้ลงส่วนราชการเจ้าของเรื่องพร้อมหมายเลขโทรศัพท์ (ถ้ามี)",
                         "department", "ข้อ ๑๒.๑"))

    if isinstance(doc, StampLetterDoc) and doc.speed is None and len(" ".join(doc.paragraphs)) > 1200:
        f.append(Finding("info", "STAMP_SCOPE", "หนังสือประทับตราใช้เฉพาะเรื่องที่ไม่ใช่เรื่องสำคัญ — ตรวจว่าเรื่องนี้เข้าข้อ ๑๓",
                         "paragraphs", "ข้อ ๑๓"))

    # ---- คู่มือการพิมพ์หนังสือ กปภ. (๒๕๕๔)
    if spec.date_be_rules:
        _check_pwa(f, doc, spec)

    # ---- หนังสือสั่งการ
    if isinstance(doc, OrderDoc):
        if not YEAR_NO_RE.match(doc.doc_no):
            f.append(Finding("error", "ORDER_NO", "ที่ ของคำสั่งต้องเป็น 'เลขที่/ปีพุทธศักราช' (เริ่ม ๑ ทุกปีปฏิทิน)",
                             "doc_no", "ข้อ ๑๖.๒"))
        if not doc.effective:
            f.append(Finding("warning", "ORDER_EFFECTIVE", "ระบุวันใช้บังคับ", "effective", "ข้อ ๑๖.๔"))

    if isinstance(doc, RegulationDoc):
        word = "ระเบียบ" if doc.doc_type == DocType.REGULATION else "ข้อบังคับ"
        arts = doc.articles
        if len(arts) < 3:
            f.append(Finding("error", "REG_ARTICLES", "ต้องมีอย่างน้อย ข้อ ๑ ชื่อ, ข้อ ๒ วันใช้บังคับ, ข้อสุดท้าย ผู้รักษาการ",
                             "articles", "ข้อ ๑๗.๖"))
        else:
            if "เรียกว่า" not in arts[0].text:
                f.append(Finding("error", "REG_NAME", f"ข้อ ๑ ต้องเป็นชื่อ{word} ('{word}นี้เรียกว่า ...')",
                                 "articles[0]", "ข้อ ๑๗.๖"))
            elif word not in arts[0].text:
                f.append(Finding("warning", "REG_WORD", f"ชื่อในข้อ ๑ ไม่ตรงชนิดเอกสาร ({word})", "articles[0]"))
            if "ใช้บังคับ" not in arts[1].text:
                f.append(Finding("error", "REG_EFFECTIVE", "ข้อ ๒ ต้องเป็นวันใช้บังคับ", "articles[1]", "ข้อ ๑๗.๖"))
            if "รักษาการ" not in arts[-1].text:
                f.append(Finding("error", "REG_KEEPER", "ข้อสุดท้ายต้องเป็นผู้รักษาการ", f"articles[{len(arts) - 1}]", "ข้อ ๑๗.๖"))
        if doc.edition and to_arabic_digits(doc.edition).strip() in {"1", "๑"}:
            f.append(Finding("info", "REG_EDITION", "ฉบับแรกไม่ต้องระบุฉบับที่", "edition", "ข้อ ๑๗.๓"))
        if doc.doc_type == DocType.BYLAW and "อาศัยอำนาจ" not in doc.preamble:
            f.append(Finding("error", "BYLAW_AUTHORITY", "ข้อบังคับต้องอ้างกฎหมายที่ให้อำนาจ", "preamble", "ข้อ ๑๘"))

    if isinstance(doc, AnnouncementDoc) and not doc.paragraphs:
        f.append(Finding("error", "ANN_BODY", "ต้องมีข้อความ (เหตุผล + สิ่งที่ประกาศ)", "paragraphs", "ข้อ ๒๐.๓"))

    # ---- หนังสือที่เจ้าหน้าที่ทำขึ้น
    if isinstance(doc, CertificateDoc):
        if not doc.body or not doc.body[0].startswith("หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า"):
            f.append(Finding("error", "CERT_OPENING", "ข้อความต้องขึ้นต้นว่า 'หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า'",
                             "body[0]", "ข้อ ๒๔.๓"))

    if isinstance(doc, MinutesDoc):
        if not doc.agenda:
            f.append(Finding("error", "MIN_AGENDA", "ต้องมีข้อความการประชุมตามระเบียบวาระ", "agenda", "ข้อ ๒๕.๙"))
        for i, a in enumerate(doc.agenda):
            if not a.resolution or a.resolution.startswith("[ระบุ"):
                f.append(Finding("warning", "MIN_RESOLUTION", f"วาระที่ {i + 1} ยังไม่มีมติ/ข้อสรุป",
                                 f"agenda[{i}].resolution", "ข้อ ๒๕.๙"))
    return f


def _check_pwa(f: list[Finding], doc: AnyDoc, spec: LayoutSpec):
    ref = "คู่มือ กปภ."
    date = getattr(doc, "date", "") or ""
    if isinstance(doc, (ExternalLetterDoc, MemoDoc, StampLetterDoc, StatementDoc)) and "พ.ศ." in date:
        f.append(Finding("warning", "PWA_DATE_NO_BE", "หนังสือภายนอก/บันทึก/ประทับตรา/แถลงการณ์/ข่าว "
                         "ไม่ต้องพิมพ์คำว่า 'พ.ศ.' หน้าปี", "date", ref))
    if isinstance(doc, (OrderDoc, RegulationDoc, AnnouncementDoc, CertificateDoc)) and date \
            and not find_placeholders(date) and "พ.ศ." not in date:
        f.append(Finding("warning", "PWA_DATE_BE", "บรรทัด 'สั่ง/ประกาศ/ให้ไว้ ณ วันที่' ต้องระบุคำว่า 'พ.ศ.'",
                         "date", ref))
    eff = getattr(doc, "effective", "") or ""
    if "ตั้งแต่" in eff and "พ.ศ." in eff:
        f.append(Finding("info", "PWA_EFFECTIVE_BE", "'ทั้งนี้ ตั้งแต่ ...' ไม่ต้องพิมพ์ 'พ.ศ.'", "effective", ref))
    if spec.doc_no_prefix and isinstance(doc, (ExternalLetterDoc, StampLetterDoc, MemoDoc, CertificateDoc)):
        no = (doc.doc_no or "").strip()
        if no and not find_placeholders(no.split("/")[0]) and not no.startswith(spec.doc_no_prefix):
            f.append(Finding("info", "PWA_DOC_NO", f"เลขที่หนังสือ กปภ. ขึ้นต้นด้วยรหัส '{spec.doc_no_prefix}' "
                             f"เช่น '{spec.doc_no_prefix} <เลขหน่วยงาน>/<เลขทะเบียน>'", "doc_no", ref))
    for where in ("owner_unit", "department"):
        v = getattr(doc, where, "") or ""
        if "ส่วนราชการ" in v:
            f.append(Finding("info", "PWA_UNIT_WORD", "กปภ. ใช้คำว่า 'หน่วยงาน' แทน 'ส่วนราชการ'", where, ref))


# ---------------------------------------------------------------------------- docx
def check_docx(path: str | Path, spec: LayoutSpec = DEFAULT_SPEC) -> list[Finding]:
    from docx import Document
    from docx.oxml.ns import qn

    d = Document(str(path) if isinstance(path, (str, Path)) else path)
    f: list[Finding] = []
    tol = 0.15
    for i, sec in enumerate(d.sections):
        for name, val, exp in (("ซ้าย", sec.left_margin, spec.margin_left_cm),
                               ("ขวา", sec.right_margin, spec.margin_right_cm)):
            cm = val.cm if val is not None else 0
            if abs(cm - exp) > tol:
                f.append(Finding("error", "MARGIN", f"ขอบ{name} {cm:.2f} ซม. (ควร {exp} ซม.)", f"section {i + 1}", "ว ๒๐๑๙"))
        if sec.page_width and abs(sec.page_width.cm - spec.page_w_cm) > tol:
            f.append(Finding("error", "PAPER", "ไม่ใช่กระดาษ A4", f"section {i + 1}"))

    def run_font(r):
        rPr = r._element.rPr
        rf = rPr.find(qn("w:rFonts")) if rPr is not None else None
        return (rf.get(qn("w:cs")) or rf.get(qn("w:ascii"))) if rf is not None else None

    def run_size(r):
        rPr = r._element.rPr
        sz = rPr.find(qn("w:szCs")) if rPr is not None else None
        if sz is not None:
            return int(sz.get(qn("w:val"))) / 2
        return r.font.size.pt if r.font.size else None

    bad_fonts, arabic, small = set(), 0, 0
    paras = d.paragraphs
    for p in paras:
        if has_arabic_digits(p.text):
            arabic += 1
        for r in p.runs:
            fn = run_font(r)
            if fn and fn not in NATIONAL_FONTS and fn != spec.font:
                bad_fonts.add(fn)
            sz = run_size(r)
            if sz and r.text.strip() and sz < spec.body_pt - 0.5:
                small += 1
    if bad_fonts:
        f.append(Finding("error", "FONT", f"พบฟอนต์ที่ไม่ใช่ฟอนต์แห่งชาติ: {', '.join(sorted(bad_fonts))}", "", "ว ๒๐๑๙"))
    if small:
        f.append(Finding("warning", "FONT_SIZE", f"พบข้อความเล็กกว่า {spec.body_pt:g} พอยท์ {small} ช่วง", ""))
    if arabic:
        f.append(Finding("info", "ARABIC_DIGITS", f"พบเลขอารบิก {arabic} ย่อหน้า (หากหน่วยงานใช้เลขไทย)"))

    has_pic = bool(d.inline_shapes) or bool(d.element.body.findall(".//" + qn("wp:anchor")))
    first = next((p.text.strip() for p in paras if p.text.strip()), "")
    no_emblem_ok = first.startswith("รายงานการประชุม") or (not spec.news_emblem and first.startswith("ข่าว"))
    if not has_pic and not no_emblem_ok:
        f.append(Finding("warning", "GARUDA", f"ไม่พบภาพ{spec.emblem_name}", "", "ว ๒๐๑๙"))

    # บันทึกข้อความ: หัว ๒๙ พอยท์ / ป้าย ๒๐ พอยท์ ตัวหนา
    for p in paras[:6]:
        if "บันทึกข้อความ" in p.text:
            sizes = {run_size(r) for r in p.runs if "บันทึกข้อความ" in r.text}
            if sizes and spec.memo_title_pt not in sizes:
                f.append(Finding("error", "MEMO_TITLE", "'บันทึกข้อความ' ต้องตัวหนา ๒๙ พอยท์", "", "ว ๒๐๑๙"))
        for label in (spec.unit_word, "วันที่", "เรื่อง"):
            for r in p.runs:
                if r.text.strip() == label and (run_size(r) != spec.memo_label_pt or not r.bold):
                    f.append(Finding("error", "MEMO_LABEL", f"'{label}' ต้องตัวหนา ๒๐ พอยท์", "", "ว ๒๐๑๙"))
    return f


def summarize(findings: list[Finding]) -> dict:
    return {
        "errors": sum(x.level == "error" for x in findings),
        "warnings": sum(x.level == "warning" for x in findings),
        "infos": sum(x.level == "info" for x in findings),
        "findings": [x.dict() for x in findings],
    }

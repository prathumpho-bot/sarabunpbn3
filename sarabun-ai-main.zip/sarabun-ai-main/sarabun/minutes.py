"""ไฟล์เสียง → ถอดความ → รายงานการประชุม (ทำงานเบื้องหลังเป็น job)

ขั้นตอน: อัปโหลด → ถอดเสียง (ภาษาไทย) → แบ่งวาระ/สรุป → .docx
โหมด: summary (สรุปตามวาระ) | verbatim (คำต่อคำตามวาระ) | transcript (ถอดความล้วน)

ASR on-premise: faster-whisper กับโมเดลภาษาไทย เช่น
  - biodatlab/whisper-th-large-v3-combined (Thonburian Whisper) แปลงเป็น CTranslate2
  - openai/whisper-large-v3 / large-v3-turbo
ไฟล์ยาวเกิน context ของ LLM → สรุปทีละช่วง (map) แล้วรวมตามวาระ (reduce)
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Literal, Optional

from .llm import LLM, prompts
from .schema import MinutesDoc

Mode = Literal["summary", "verbatim", "transcript"]


@dataclass
class Segment:
    start: float
    end: float
    text: str


def transcribe(audio_path: str | Path, model_name: Optional[str] = None,
               device: str = "cuda") -> Iterator[Segment]:
    """ffmpeg รองรับ wav/m4a/mp3/mp4/aac/ogg/webm/mov ฯลฯ ผ่าน faster-whisper อยู่แล้ว"""
    from faster_whisper import WhisperModel  # import ช้า โหลดเมื่อใช้

    model = WhisperModel(model_name or os.getenv("SARABUN_ASR_MODEL", "large-v3"),
                         device=device, compute_type="float16" if device == "cuda" else "int8")
    segments, _info = model.transcribe(str(audio_path), language="th", vad_filter=True,
                                       beam_size=5)
    for s in segments:
        yield Segment(s.start, s.end, s.text.strip())


def chunk_transcript(segments: list[Segment], max_chars: int = 12000) -> list[str]:
    chunks, buf = [], []
    size = 0
    for s in segments:
        line = f"[{int(s.start // 60):02d}:{int(s.start % 60):02d}] {s.text}"
        if size + len(line) > max_chars and buf:
            chunks.append("\n".join(buf))
            buf, size = [], 0
        buf.append(line)
        size += len(line)
    if buf:
        chunks.append("\n".join(buf))
    return chunks


def summarize(llm: LLM, segments: list[Segment], *, title: str = "", focus: str = "-",
              mode: Mode = "summary") -> MinutesDoc | str:
    if mode == "transcript":
        return "\n".join(s.text for s in segments)
    chunks = chunk_transcript(segments)
    system = prompts.MINUTES.format(focus=focus)
    if mode == "verbatim":
        system += "\nโหมดคำต่อคำ: ใส่ทุกถ้อยคำในส่วน discussion ของวาระนั้น ห้ามย่อ"
    schema = MinutesDoc.model_json_schema()
    if len(chunks) == 1:
        raw = llm.chat_json(system, f"ชื่อการประชุม: {title or '[ระบุ]'}\n\n{chunks[0]}", schema)
    else:
        # map: สรุปทีละช่วง → reduce: รวมเป็นวาระเดียวกัน
        partials = [llm.chat_json(system, f"(ช่วงที่ {i + 1}/{len(chunks)})\n{c}", schema)
                    for i, c in enumerate(chunks)]
        raw = llm.chat_json(system + "\nรวมผลสรุปบางส่วนต่อไปนี้ให้เป็นรายงานฉบับเดียว รวมวาระซ้ำเข้าด้วยกัน",
                            str(partials), schema)
    raw["doc_type"] = "minutes"
    return MinutesDoc.model_validate(raw)

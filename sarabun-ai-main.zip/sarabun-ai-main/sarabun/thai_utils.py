"""Thai text helpers: Thai numerals, Buddhist-era dates, placeholders."""
from __future__ import annotations

import re
from datetime import date

ARABIC = "0123456789"
THAI = "๐๑๒๓๔๕๖๗๘๙"
_TO_THAI = str.maketrans(ARABIC, THAI)
_TO_ARABIC = str.maketrans(THAI, ARABIC)

THAI_MONTHS = [
    "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
    "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม",
]

# [ระบุ...] — fields the AI must NOT invent; left for the user to fill.
PLACEHOLDER_RE = re.compile(r"\[ระบุ[^\]]*\]")
ARABIC_DIGIT_RE = re.compile(r"[0-9]")
# Skip URLs / e-mail addresses when converting digits.
_KEEP_RE = re.compile(r"(https?://\S+|[\w.+-]+@[\w-]+\.[\w.]+)")


def to_thai_digits(text: str) -> str:
    """Convert Arabic digits to Thai digits, leaving URLs/e-mails untouched."""
    if not text:
        return text
    parts = _KEEP_RE.split(text)
    return "".join(p if _KEEP_RE.fullmatch(p) else p.translate(_TO_THAI) for p in parts)


def to_arabic_digits(text: str) -> str:
    return text.translate(_TO_ARABIC)


def thai_date(d: date | None = None, *, with_day_prefix: bool = False) -> str:
    """date(2026,10,3) -> '๓ ตุลาคม ๒๕๖๙'"""
    d = d or date.today()
    s = f"{d.day} {THAI_MONTHS[d.month - 1]} {d.year + 543}"
    if with_day_prefix:
        s = "วันที่ " + s
    return to_thai_digits(s)


def find_placeholders(text: str) -> list[str]:
    return PLACEHOLDER_RE.findall(text or "")


def has_arabic_digits(text: str) -> bool:
    stripped = _KEEP_RE.sub("", text or "")
    return bool(ARABIC_DIGIT_RE.search(stripped))

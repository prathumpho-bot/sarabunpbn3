"""สร้างหนังสือราชการจากบรรทัดคำสั่ง — ไม่ต้องรันเว็บ/ฐานข้อมูล/GPU

    python -m sarabun "ขออนุมัติจัดอบรมพนักงาน ๕๐ คน ๑๐ พ.ย. ๒๕๖๙" --type memo -o บันทึก.docx

ค่าเริ่มต้นใช้ ThaiLLM API (ต้องมี THAILLM_API_KEY ใน env หรือไฟล์ .env ในโฟลเดอร์ที่รัน)
และรูปแบบการพิมพ์ตามแม่แบบ/คู่มือ กปภ. (PWA_SPEC)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import fields
from pathlib import Path

from . import checker
from .llm import LLMError, llm_from_env
from .render import DocxRenderer
from .schema import DOC_TYPE_TH, DocType
from .service import DraftService, ExternalLLMNotAllowed, UserProfile, parse_doc
from .style import get_spec

TYPES = ", ".join(f"{t.value}={DOC_TYPE_TH[t]}" for t in DocType)


def load_dotenv(path: Path = Path(".env")) -> None:
    """อ่าน KEY=VALUE จาก .env (ไม่ทับค่าที่ตั้งไว้แล้ว)"""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.split(" #")[0].strip().strip('"').strip("'"))


def build_profile(args) -> UserProfile:
    data: dict = {}
    if args.profile_file:
        data = json.loads(Path(args.profile_file).read_text(encoding="utf-8-sig"))
    for flag, key in (("dept", "department"), ("phone", "phone"), ("email", "email"),
                      ("doc_no_prefix", "doc_no_prefix"), ("signer", "signer_name")):
        if getattr(args, flag):
            data[key] = getattr(args, flag)
    if args.position:
        data["signer_position"] = [args.position]
    known = {f.name for f in fields(UserProfile)}
    return UserProfile(**{k: v for k, v in data.items() if k in known})


def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):           # Windows console: แสดงภาษาไทยได้
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    p = argparse.ArgumentParser(prog="python -m sarabun", description="ร่างหนังสือราชการด้วย LLM แล้วจัดรูปแบบเป็น .docx",
                                formatter_class=argparse.RawDescriptionHelpFormatter,
                                epilog=f"ชนิดหนังสือ: {TYPES}")
    p.add_argument("request", nargs="?", help="สิ่งที่ต้องการ (ภาษาไทย) — หรือใช้ --request-file")
    p.add_argument("--request-file", help="อ่านคำขอจากไฟล์ข้อความ (UTF-8)")
    p.add_argument("-t", "--type", help="ชนิดหนังสือ (ไม่ระบุ = ให้ LLM แนะนำ)")
    p.add_argument("-o", "--out", help="ไฟล์ .docx ที่จะสร้าง (ค่าเริ่มต้น: <ชนิด>.docx)")
    p.add_argument("--json-out", help="บันทึกร่าง (JSON) ไว้แก้ไขต่อ")
    p.add_argument("--from-json", help="จัดรูปแบบจากร่าง JSON ที่มีอยู่ (ไม่เรียก LLM)")
    p.add_argument("--revise", help="คำสั่งแก้ไขร่าง (ใช้คู่กับ --from-json)")
    p.add_argument("--provider", help="thaillm (ค่าเริ่มต้น) | onprem | thaillm+onprem")
    p.add_argument("--model", help="typhoon | openthaigpt | pathumma | thalle")
    p.add_argument("--profile", default=os.getenv("SARABUN_PROFILE", "pwa"), help="pwa (ค่าเริ่มต้น) | opm")
    p.add_argument("--profile-file", help="ไฟล์ JSON ข้อมูลหน่วยงาน/ผู้ลงนาม (ดู profile.example.json)")
    p.add_argument("--dept", help="หน่วยงานเจ้าของเรื่อง")
    p.add_argument("--phone", help="โทรศัพท์หน่วยงาน")
    p.add_argument("--email")
    p.add_argument("--doc-no-prefix", dest="doc_no_prefix", help="เช่น 'มท <เลขประจำหน่วยงาน>'")
    p.add_argument("--signer", help="ชื่อผู้ลงนาม")
    p.add_argument("--position", help="ตำแหน่งผู้ลงนาม")
    p.add_argument("--secrecy", choices=["ลับ", "ลับมาก", "ลับที่สุด"], help="ชั้นความลับ (ห้ามส่ง ThaiLLM)")
    args = p.parse_args(argv)

    load_dotenv()
    if args.model:
        os.environ["THAILLM_MODEL"] = args.model
    renderer = DocxRenderer(get_spec(args.profile))

    try:
        if args.from_json and not args.revise:
            doc = parse_doc(json.loads(Path(args.from_json).read_text(encoding="utf-8-sig")))
            svc = DraftService(None, renderer)
        else:
            llm = llm_from_env(args.provider or os.getenv("SARABUN_LLM_PROVIDER", "thaillm"))
            svc = DraftService(llm, renderer)
            info = llm.info() if hasattr(llm, "info") else {}
            print(f"LLM: {info.get('provider')} {info.get('model', '')}", file=sys.stderr)
            if args.from_json:
                doc = parse_doc(json.loads(Path(args.from_json).read_text(encoding="utf-8-sig")))
                print("กำลังแก้ไขร่าง…", file=sys.stderr)
                doc = svc.revise(doc, args.revise)
            else:
                request = Path(args.request_file).read_text(encoding="utf-8-sig") if args.request_file \
                    else args.request
                if not request:
                    p.error("ต้องระบุคำขอ หรือ --request-file หรือ --from-json")
                if args.type:
                    doc_type = DocType(args.type)
                else:
                    c = svc.classify(request)
                    doc_type = DocType(c["doc_type"])
                    print(f"ชนิดที่แนะนำ: {DOC_TYPE_TH[doc_type]} — {c.get('reason', '')}", file=sys.stderr)
                print(f"กำลังร่าง{DOC_TYPE_TH[doc_type]}…", file=sys.stderr)
                doc = svc.draft(request, doc_type, build_profile(args), secrecy=args.secrecy)
    except ExternalLLMNotAllowed as e:
        print(f"ไม่ส่ง: {e}", file=sys.stderr)
        return 3
    except (LLMError, ValueError) as e:
        print(f"ผิดพลาด: {e}", file=sys.stderr)
        return 2

    out = Path(args.out or f"{DOC_TYPE_TH[doc.doc_type]}.docx")
    renderer.render_to(doc, out)
    if args.json_out:
        Path(args.json_out).write_text(doc.model_dump_json(indent=2), encoding="utf-8")
    result = checker.summarize(checker.check_document(doc, renderer.spec))
    print(f"สร้างไฟล์ {out}  (error {result['errors']} · warning {result['warnings']} · info {result['infos']})")
    for f in result["findings"]:
        if f["level"] != "info":
            print(f"  [{f['level']}] {f['message']}" + (f"  ({f['where']})" if f.get("where") else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""Orchestration: คำขอภาษาไทย → ชนิดหนังสือ → JSON ร่าง → ตรวจ → .docx

    classify()  ขั้น ๑  แนะนำชนิดหนังสือ (ผู้ใช้ยืนยันก่อน)
    draft()     ขั้น ๒  LLM เติม field ตาม schema ของชนิดนั้น + เติมข้อมูลหน่วยงานจาก profile
    revise()    ขั้น ๓  แก้ตามคำสั่งในแชต
    check()     ขั้น ๔  rule-based checker (+ LLM review ถ้าเปิด)
    render()    ขั้น ๕  docx
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Optional

from pydantic import BaseModel, TypeAdapter, ValidationError

from . import checker, salutations
from .llm import LLM
from .llm import prompts
from .render import DocxRenderer
from . import profiles
from .profiles.pwa import PWA_HQ
from .schema import (MODEL_BY_TYPE, AnyDoc, CertificateDoc, DocType, ExternalLetterDoc, MinutesDoc,
                     StampLetterDoc)


@dataclass
class UserProfile:
    """ข้อมูลที่ผู้ใช้กรอกครั้งเดียว: หน่วยงาน ผู้ลงนาม ผู้รับประจำ รหัสหนังสือ"""
    department: str = "กองบริหารระบบข้อมูลสารสนเทศ"
    org: str = "การประปาส่วนภูมิภาค"
    doc_no_prefix: str = "มท [ระบุ]"                                  # คู่มือ กปภ.: ที่ มท ๕๕xxx/...
    address: list[str] = field(default_factory=lambda: list(PWA_HQ))   # คู่มือ กปภ. แบบที่ ๑
    phone: str = "[ระบุ]"
    email: str = ""
    signer_name: str = "[ระบุชื่อผู้ลงนาม]"
    signer_position: list[str] = field(default_factory=lambda: ["[ระบุตำแหน่ง]"])
    frequent_recipients: list[str] = field(default_factory=list)
    style_notes: list[str] = field(default_factory=list)

    def as_prompt(self) -> str:
        return json.dumps(self.__dict__, ensure_ascii=False, indent=1)


class ExternalLLMNotAllowed(PermissionError):
    """หนังสือที่มีชั้นความลับห้ามส่งให้ LLM ภายนอก (ThaiLLM) — ระเบียบว่าด้วยการรักษาความลับของทางราชการ"""


class DraftService:
    def __init__(self, llm: LLM, renderer: Optional[DocxRenderer] = None, llm_review: bool = False):
        self.llm = llm
        self.renderer = renderer or DocxRenderer()
        self.llm_review = llm_review

    # ขั้น ๑
    def classify(self, request: str) -> dict:
        out = self.llm.chat_json(prompts.CLASSIFY, request)
        out["doc_type"] = DocType(out["doc_type"]).value
        return out

    # ขั้น ๒
    def draft(self, request: str, doc_type: DocType, profile: UserProfile, *,
              secrecy: Optional[str] = None) -> AnyDoc:
        llm = self._llm_for(secrecy)
        model = MODEL_BY_TYPE[doc_type]
        org_rules = profiles.org_rules(self.renderer.spec.profile)
        system = prompts.draft_prompt(doc_type.value, profile.as_prompt(), "\n".join(profile.style_notes), org_rules)
        user = f"ชนิดหนังสือ: {doc_type.value}\nคำขอ: {request}"
        doc = self._ask(model, system, user, doc_type, llm=llm)
        if secrecy:
            doc.secrecy = secrecy
        return self._postprocess(doc, profile)

    # ขั้น ๓
    def revise(self, doc: AnyDoc, instruction: str) -> AnyDoc:
        llm = self._llm_for(getattr(doc, "secrecy", None))
        model = type(doc)
        user = f"ร่างปัจจุบัน:\n{doc.model_dump_json(indent=1)}\n\nคำสั่งแก้ไข: {instruction}"
        return self._ask(model, prompts.REVISE, user, doc.doc_type, llm=llm)

    def _ask(self, model, system: str, user: str, doc_type: DocType, repairs: int = 1, llm=None):
        """เรียก LLM แล้วตรวจกับ schema — ถ้าไม่ผ่าน ส่งข้อผิดพลาดกลับให้แก้ (โมเดล ๘B เช่น ThaiLLM พลาดบ้าง)"""
        schema = model.model_json_schema()
        msg = user
        for attempt in range(repairs + 1):
            raw = (llm or self.llm).chat_json(system, msg, schema=schema)
            raw["doc_type"] = doc_type.value
            try:
                return model.model_validate(raw)
            except ValidationError as e:
                if attempt == repairs:
                    raise
                errs = "; ".join(f"{'.'.join(map(str, x['loc']))}: {x['msg']}" for x in e.errors()[:10])
                msg = (f"{user}\n\nJSON ที่ตอบมาไม่ตรง schema ({errs})\n"
                       f"JSON เดิม: {json.dumps(raw, ensure_ascii=False)[:3000]}\nแก้แล้วตอบ JSON ทั้งก้อนใหม่")

    def _llm_for(self, secrecy: Optional[str]):
        """หนังสือชั้นความลับใช้ได้เฉพาะ LLM ภายใน (thaillm+onprem → onprem) ถ้าไม่มีให้ปฏิเสธ"""
        if not secrecy or not getattr(self.llm, "external", False):
            return self.llm
        inner = self.llm.internal_only() if hasattr(self.llm, "internal_only") else None
        if inner is None:
            self._guard(secrecy)
        return inner

    def _guard(self, secrecy: Optional[str]):
        if secrecy and getattr(self.llm, "external", False):
            raise ExternalLLMNotAllowed(
                f"หนังสือชั้นความลับ '{secrecy}' ห้ามส่งให้ LLM ภายนอก — ใช้ SARABUN_LLM_PROVIDER=onprem")

    # ขั้น ๔
    def check(self, doc: AnyDoc) -> dict:
        findings = checker.check_document(doc, self.renderer.spec)
        if self.llm_review:
            try:
                extra = self._llm_for(getattr(doc, "secrecy", None)).chat_json(prompts.REVIEW, doc.model_dump_json())
                findings += [checker.Finding(**x) for x in extra.get("findings", [])]
            except Exception:  # LLM review เป็นส่วนเสริม ห้ามทำให้ทั้งระบบล้ม
                pass
        return checker.summarize(findings)

    # ขั้น ๕
    def render(self, doc: AnyDoc) -> bytes:
        return self.renderer.render(doc)

    # ------------------------------------------------------------------
    @staticmethod
    def _postprocess(doc: AnyDoc, p: UserProfile) -> AnyDoc:
        """เติม/แก้ส่วนที่ deterministic — ไม่ปล่อยให้ LLM ตัดสินเอง"""
        if hasattr(doc, "to"):
            doc.to = doc.to.removeprefix("กราบเรียน").removeprefix("เรียน").strip()
        if isinstance(doc, ExternalLetterDoc):
            sal, clo = salutations.suggest(doc.to)
            doc.salutation, doc.closing = sal, clo
            if not doc.agency or doc.agency[0].startswith("[ระบุ"):
                doc.agency = list(p.address)
            doc.owner_unit = doc.owner_unit if not doc.owner_unit.startswith("[ระบุ") else p.department
            if doc.phone.startswith("[ระบุ") and not p.phone.startswith("[ระบุ"):
                doc.phone = p.phone
            doc.email = doc.email or (p.email or None)
        if isinstance(doc, StampLetterDoc):
            doc.owner_unit = doc.owner_unit if not doc.owner_unit.startswith("[ระบุ") else p.department
            doc.issuer = doc.issuer if not doc.issuer.startswith("[ระบุ") else p.org
        if isinstance(doc, CertificateDoc) and (not doc.agency or doc.agency[0].startswith("[ระบุ")):
            doc.agency = list(p.address)
        if hasattr(doc, "signer") and doc.signer.name.startswith("[ระบุ"):
            doc.signer.name, doc.signer.position = p.signer_name, list(p.signer_position)
        if hasattr(doc, "signer"):
            doc.signer.name = doc.signer.name.strip("() ")
        return doc


def parse_doc(data: dict) -> AnyDoc:
    model = MODEL_BY_TYPE[DocType(data["doc_type"])]
    return model.model_validate(data)

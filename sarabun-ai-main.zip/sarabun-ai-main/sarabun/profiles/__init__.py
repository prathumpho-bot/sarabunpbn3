"""โปรไฟล์หน่วยงาน — ค่าการพิมพ์ (LayoutSpec) + ข้อกำหนดเพิ่มให้ LLM

เพิ่มหน่วยงานใหม่: สร้าง sarabun/profiles/<ชื่อ>.py ที่มี SPEC (และ RULES ถ้ามี) แล้วลงทะเบียนใน PROFILES
ดู CONTRIBUTING.md
"""
from __future__ import annotations

from ..style import DEFAULT_SPEC, LayoutSpec
from . import pwa

PROFILES: dict[str, tuple[LayoutSpec, str]] = {
    "opm": (DEFAULT_SPEC, ""),                 # แนวทางกลาง นร ๐๑๐๖/ว ๒๐๑๙ (ทุกส่วนราชการ)
    "pwa": (pwa.PWA_SPEC, pwa.PWA_RULES),     # การประปาส่วนภูมิภาค
}


def get_spec(profile: str | None) -> LayoutSpec:
    return PROFILES.get((profile or "opm").lower(), PROFILES["opm"])[0]


def org_rules(profile: str | None) -> str:
    """ข้อกำหนดเฉพาะหน่วยงานที่ต่อท้าย system prompt"""
    return PROFILES.get((profile or "opm").lower(), PROFILES["opm"])[1]

# เอกสารอ้างอิง

repo นี้ไม่เก็บไฟล์ต้นฉบับ — ใช้ตามขั้นตอนด้านล่างเพื่อเปิดชุดทดสอบเทียบมาตรฐาน (tests ที่ถูกข้ามจะทำงานเมื่อมีไฟล์ครบ)

## 1. สำนักนายกรัฐมนตรี (สาธารณะ) → `references/opm_w2019/`

ดาวน์โหลดจาก <https://www.opm.go.th/th/legal/content/37674/>
"การพิมพ์หนังสือราชการภาษาไทยด้วยโปรแกรมการพิมพ์ในเครื่องคอมพิวเตอร์และตัวอย่างการพิมพ์"

| ไฟล์ | เนื้อหา |
| --- | --- |
| `CN20189.pdf` | หนังสือ ที่ นร 0106/ว 2019 ลงวันที่ 30 พ.ย. 2553 |
| `Explain_Typing_.pdf` | คำอธิบายการพิมพ์ |
| `example_Out.pdf`, `example_In.pdf`, `example_Seal.pdf` | ตัวอย่างการพิมพ์ 3 แบบ |
| `template_Out_.doc`, `template_in.doc`, `template_seal.doc` | แผ่นแบบ (template) |

แปลงแผ่นแบบเป็น .docx (ชุดทดสอบอ่าน .docx):

```bash
cd references/opm_w2019 && soffice --headless --convert-to docx *.doc
```

ใช้ใน `tests/test_official.py` และ `tools/compare_official.py`

## 2. การประปาส่วนภูมิภาค (ภายใน — ห้าม commit) → `private/`

ขอจากงานสารบรรณ กองบริการกลาง / ผู้ดูแลระบบภายใน กปภ.

```
private/
├── pwa/
│   ├── pwa_emblem.png          ตราการประปาส่วนภูมิภาค (PNG พื้นโปร่ง)
│   └── pwa_memo_footer.png     โลโก้ท้ายบันทึกข้อความ
├── pwa_template/
│   └── แบบหนังสือภายใน_v5.docx  แม่แบบหนังสือภายในปัจจุบัน
└── pwa_manual_2554/
    └── pwa-old-03.pdf           คู่มือการพิมพ์หนังสือ กปภ. (ม.ค. 2554)
```

ตั้ง `SARABUN_ASSETS_DIR` เพื่อชี้โฟลเดอร์ตราในตำแหน่งอื่นได้ (ค่าเริ่มต้น `private/pwa`)
ถ้าไม่มีไฟล์ตรา ระบบใส่กรอบแทนตราและไม่ใส่โลโก้ท้ายกระดาษ — เอกสารยังสร้างได้ตามปกติ

ใช้ใน `tests/test_pwa_template.py` และ `tools/compare_pwa.py`

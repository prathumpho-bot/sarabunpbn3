"""REST API — รันภายในเครือข่าย กปภ.:  uvicorn api.main:app --host 0.0.0.0 --port 8080"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel

from sarabun import checker
from sarabun.llm import LLMError, llm_from_env
from sarabun.render import DocxRenderer
from sarabun.style import get_spec
from sarabun.schema import DOC_TYPE_TH, DocType
from sarabun.service import DraftService, ExternalLLMNotAllowed, UserProfile, parse_doc

app = FastAPI(title="SARABUN.AI", version="0.1.0")
# SARABUN_PROFILE: pwa (คู่มือการพิมพ์หนังสือ กปภ.) | opm (แนวทาง นร ๐๑๐๖/ว ๒๐๑๙ ทั่วไป)
PROFILE = os.getenv("SARABUN_PROFILE", "pwa")
SARABUN_EMBLEM = os.getenv("SARABUN_EMBLEM_PNG") or os.getenv("SARABUN_GARUDA_PNG")


def get_renderer(profile: Optional[str] = None) -> DocxRenderer:
    spec = get_spec(profile or PROFILE)
    return DocxRenderer(spec, garuda_path=SARABUN_EMBLEM if spec.profile == "opm" else
                        (os.getenv("SARABUN_EMBLEM_PNG") or None))


renderer = get_renderer()
_service: Optional[DraftService] = None


def service() -> DraftService:
    global _service
    if _service is None:
        _service = DraftService(llm_from_env(), renderer, llm_review=os.getenv("SARABUN_LLM_REVIEW") == "1")
    return _service


class ClassifyIn(BaseModel):
    request: str


class DraftIn(BaseModel):
    request: str
    doc_type: DocType
    profile: dict[str, Any] = {}
    secrecy: Optional[str] = None      # ลับ/ลับมาก/ลับที่สุด → ห้ามใช้ LLM ภายนอก


class ReviseIn(BaseModel):
    doc: dict[str, Any]
    instruction: str


@app.get("/api/llm")
def llm_info():
    """provider ที่ใช้อยู่ (onprem / thaillm / thaillm+onprem) และข้อมูลออกนอก กปภ. หรือไม่"""
    llm = service().llm
    return llm.info() if hasattr(llm, "info") else {"provider": type(llm).__name__}


@app.exception_handler(ExternalLLMNotAllowed)
def _secret(_req, e):
    return JSONResponse({"detail": str(e)}, status_code=403)


@app.exception_handler(LLMError)
def _llm_err(_req, e):
    return JSONResponse({"detail": f"LLM: {e}"}, status_code=502)


@app.get("/api/doc-types")
def doc_types():
    return [{"id": t.value, "name": DOC_TYPE_TH[t]} for t in DocType]


@app.post("/api/classify")
def classify(body: ClassifyIn):
    return service().classify(body.request)


@app.post("/api/draft")
def draft(body: DraftIn):
    doc = service().draft(body.request, body.doc_type, UserProfile(**body.profile), secrecy=body.secrecy)
    return {"doc": doc.model_dump(mode="json"), "check": service().check(doc)}


@app.post("/api/revise")
def revise(body: ReviseIn):
    doc = service().revise(parse_doc(body.doc), body.instruction)
    return {"doc": doc.model_dump(mode="json"), "check": service().check(doc)}


@app.post("/api/check")
def check(doc: dict[str, Any], profile: Optional[str] = None):
    return checker.summarize(checker.check_document(parse_doc(doc), get_spec(profile or PROFILE)))


@app.post("/api/check-docx")
async def check_docx(file: UploadFile = File(...), profile: Optional[str] = None):
    if not file.filename.lower().endswith(".docx"):
        raise HTTPException(400, "รองรับเฉพาะ .docx")
    with tempfile.NamedTemporaryFile(suffix=".docx") as tmp:
        tmp.write(await file.read())
        tmp.flush()
        return checker.summarize(checker.check_docx(tmp.name, get_spec(profile or PROFILE)))


@app.post("/api/render")
def render(doc: dict[str, Any], profile: Optional[str] = None):
    d = parse_doc(doc)
    data = (get_renderer(profile) if profile else renderer).render(d)
    name = f"{DOC_TYPE_TH[d.doc_type]}-{getattr(d, 'subject', getattr(d, 'title', 'เอกสาร'))[:40]}.docx"
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})


@app.get("/")
def index():
    return FileResponse(Path(__file__).parent / "static" / "index.html")
